/**
 * BibliothèquePlus Authentication JavaScript
 * Handles login and registration functionality
 */

// DOM Elements
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const togglePasswordButtons = document.querySelectorAll('.toggle-password');
const accountTypeOptions = document.querySelectorAll('.account-type-option');

// Initialize the auth page
document.addEventListener('DOMContentLoaded', () => {
    // Check if already logged in, redirect if so
    if (localStorage.getItem('user')) {
        window.location.href = 'index.html';
        return;
    }
    
    // Set up event listeners
    setupFormListeners();
    setupPasswordToggles();
    setupAccountTypeOptions();
});

/**
 * Set up form event listeners
 */
function setupFormListeners() {
    // Login form submission
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            if (!validateForm(loginForm)) {
                return;
            }
            
            // Get form values
            const username = loginForm.querySelector('#login-username').value;
            const password = loginForm.querySelector('#login-password').value;
            const rememberMe = loginForm.querySelector('#remember-me').checked;
            
            // Show loading state
            const submitButton = loginForm.querySelector('#login-submit');
            const originalButtonText = submitButton.innerHTML;
            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Connexion...';
            
            try {
                // In a real app, this would call the login API
                // For demo, simulate API call with timeout
                await new Promise(resolve => setTimeout(resolve, 1000));
                
                // Simulate a successful login with dummy user data
                const userData = {
                    id: 1,
                    username: username,
                    email: `${username.toLowerCase()}@example.com`,
                    fullName: username.charAt(0).toUpperCase() + username.slice(1) + ' Dupont',
                    role: 'buyer',
                    // Don't store the password in local storage in a real app!
                };
                
                // Store user data in localStorage
                localStorage.setItem('user', JSON.stringify(userData));
                
                // Show success message
                showToast('Connexion réussie! Redirection...', 'success');
                
                // Redirect to home page
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1000);
            } catch (error) {
                console.error('Login error:', error);
                showToast('Échec de la connexion. Veuillez vérifier vos identifiants.', 'error');
                
                // Reset button state
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
            }
        });
    }
    
    // Registration form submission
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            if (!validateForm(registerForm)) {
                return;
            }
            
            // Validate password matching
            const password = registerForm.querySelector('#register-password').value;
            const confirmPassword = registerForm.querySelector('#register-confirm-password').value;
            
            if (password !== confirmPassword) {
                const confirmPasswordInput = registerForm.querySelector('#register-confirm-password');
                confirmPasswordInput.classList.add('is-invalid');
                const feedback = confirmPasswordInput.nextElementSibling.nextElementSibling;
                feedback.textContent = 'Les mots de passe ne correspondent pas';
                return;
            }
            
            // Get form values
            const username = registerForm.querySelector('#register-username').value;
            const email = registerForm.querySelector('#register-email').value;
            const role = registerForm.querySelector('input[name="role"]:checked').value;
            
            // Show loading state
            const submitButton = registerForm.querySelector('#register-submit');
            const originalButtonText = submitButton.innerHTML;
            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Création du compte...';
            
            try {
                // In a real app, this would call the registration API
                // For demo, simulate API call with timeout
                await new Promise(resolve => setTimeout(resolve, 1500));
                
                // Simulate a successful registration with dummy user data
                const userData = {
                    id: 1,
                    username: username,
                    email: email,
                    fullName: '',
                    role: role,
                    // Don't store the password in local storage in a real app!
                };
                
                // Store user data in localStorage
                localStorage.setItem('user', JSON.stringify(userData));
                
                // Show success message
                showToast('Inscription réussie! Redirection...', 'success');
                
                // Redirect to home page
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1000);
            } catch (error) {
                console.error('Registration error:', error);
                showToast('Échec de l\'inscription. Veuillez réessayer.', 'error');
                
                // Reset button state
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
            }
        });
    }
}

/**
 * Set up password toggle buttons
 */
function setupPasswordToggles() {
    togglePasswordButtons.forEach(button => {
        button.addEventListener('click', () => {
            const input = button.previousElementSibling;
            const icon = button.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
}

/**
 * Set up account type option styling
 */
function setupAccountTypeOptions() {
    // Add selected styling to account type options
    accountTypeOptions.forEach(option => {
        const radio = option.querySelector('input[type="radio"]');
        
        // Initial state
        if (radio.checked) {
            option.classList.add('border-primary', 'bg-primary', 'bg-opacity-5');
        }
        
        // Handle click on the entire div
        option.addEventListener('click', () => {
            // Set radio as checked
            radio.checked = true;
            
            // Update styling for all options
            accountTypeOptions.forEach(opt => {
                const r = opt.querySelector('input[type="radio"]');
                if (r.checked) {
                    opt.classList.add('border-primary', 'bg-primary', 'bg-opacity-5');
                } else {
                    opt.classList.remove('border-primary', 'bg-primary', 'bg-opacity-5');
                }
            });
        });
        
        // Handle radio change
        radio.addEventListener('change', () => {
            // Update styling for all options
            accountTypeOptions.forEach(opt => {
                const r = opt.querySelector('input[type="radio"]');
                if (r.checked) {
                    opt.classList.add('border-primary', 'bg-primary', 'bg-opacity-5');
                } else {
                    opt.classList.remove('border-primary', 'bg-primary', 'bg-opacity-5');
                }
            });
        });
    });
}

/**
 * Validate a single input field
 * @param {HTMLInputElement} input - The input to validate
 * @returns {boolean} Whether the input is valid
 */
function validateInput(input) {
    let isValid = true;
    const feedback = input.nextElementSibling && input.nextElementSibling.classList.contains('invalid-feedback') 
        ? input.nextElementSibling 
        : input.nextElementSibling && input.nextElementSibling.nextElementSibling;
    
    if (!feedback) return true;
    
    // Required validation
    if (input.hasAttribute('required') && !input.value.trim()) {
        isValid = false;
        input.classList.add('is-invalid');
        feedback.textContent = 'Ce champ est obligatoire';
        return false;
    }
    
    // Email validation
    if (input.type === 'email' && input.value && !isValidEmail(input.value)) {
        isValid = false;
        input.classList.add('is-invalid');
        feedback.textContent = 'Veuillez entrer une adresse email valide';
        return false;
    }
    
    // Password validation
    if (input.id === 'register-password' && input.value.length < 6) {
        isValid = false;
        input.classList.add('is-invalid');
        feedback.textContent = 'Le mot de passe doit contenir au moins 6 caractères';
        return false;
    }
    
    // If we got here, the input is valid
    input.classList.remove('is-invalid');
    return isValid;
}

/**
 * Simulate login API call (Replace with real API call in production)
 * @param {string} username - The username
 * @param {string} password - The password
 * @returns {Promise} A promise that resolves to the user data
 */
async function loginApi(username, password) {
    // Simulate API call
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // For demo purposes, accept any username/password
            // In a real app, this would validate against the database
            if (username && password) {
                resolve({
                    id: 1,
                    username,
                    email: `${username.toLowerCase()}@example.com`,
                    fullName: username.charAt(0).toUpperCase() + username.slice(1) + ' Dupont',
                    role: 'buyer'
                });
            } else {
                reject(new Error('Invalid credentials'));
            }
        }, 1000);
    });
}

/**
 * Simulate registration API call (Replace with real API call in production)
 * @param {Object} userData - The user data to register
 * @returns {Promise} A promise that resolves to the user data
 */
async function registerApi(userData) {
    // Simulate API call
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // For demo purposes, accept any registration
            // In a real app, this would create a new user in the database
            if (userData.username && userData.email && userData.password) {
                resolve({
                    id: 1,
                    username: userData.username,
                    email: userData.email,
                    fullName: '',
                    role: userData.role
                });
            } else {
                reject(new Error('Invalid user data'));
            }
        }, 1500);
    });
}