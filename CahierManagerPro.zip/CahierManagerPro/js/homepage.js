/**
 * BibliothèquePlus Homepage JavaScript
 * Handles functionality specific to the homepage
 */

// DOM Elements
const featuredBooksContainer = document.getElementById('featured-books');
const categoriesContainer = document.getElementById('categories-list');
const bestsellerBooksContainer = document.getElementById('bestseller-books');

// Initialize the homepage
document.addEventListener('DOMContentLoaded', () => {
    // Load featured books
    loadFeaturedBooks();
    
    // Load categories
    loadCategories();
    
    // Load bestseller books
    loadBestsellerBooks();
});

/**
 * Load featured books from API
 */
async function loadFeaturedBooks() {
    try {
        // In a real app, this would be an API call
        // For now, we'll use sample data
        const books = await fetchBooks(true);
        
        if (featuredBooksContainer) {
            // Clear loading placeholders
            featuredBooksContainer.innerHTML = '';
            
            // Create book cards
            books.forEach(book => {
                featuredBooksContainer.appendChild(createBookCard(book));
            });
        }
    } catch (error) {
        console.error('Error loading featured books:', error);
        showToast('Erreur lors du chargement des livres à la une', 'error');
    }
}

/**
 * Load categories from API
 */
async function loadCategories() {
    try {
        // In a real app, this would be an API call
        // For now, we'll use sample data
        const categories = await fetchCategories();
        
        if (categoriesContainer) {
            // Clear loading placeholders
            categoriesContainer.innerHTML = '';
            
            // Create category cards
            categories.forEach(category => {
                categoriesContainer.appendChild(createCategoryCard(category));
            });
        }
    } catch (error) {
        console.error('Error loading categories:', error);
        showToast('Erreur lors du chargement des catégories', 'error');
    }
}

/**
 * Load bestseller books from API
 */
async function loadBestsellerBooks() {
    try {
        // In a real app, this would be an API call
        // For now, we'll use sample data
        const books = await fetchBooks(false, true);
        
        if (bestsellerBooksContainer) {
            // Clear loading placeholders
            bestsellerBooksContainer.innerHTML = '';
            
            // Create book cards
            books.forEach((book, index) => {
                bestsellerBooksContainer.appendChild(createBookCard(book, index + 1));
            });
        }
    } catch (error) {
        console.error('Error loading bestseller books:', error);
        showToast('Erreur lors du chargement des meilleures ventes', 'error');
    }
}

/**
 * Create a book card element
 * @param {Object} book - The book data
 * @param {number} rank - Optional bestseller rank
 * @returns {HTMLElement} The book card element
 */
function createBookCard(book, rank = null) {
    const card = document.createElement('div');
    card.className = 'book-card bg-white rounded-lg shadow overflow-hidden flex flex-col';
    
    // Calculate discount percentage if there's an old price
    let discountPercent = null;
    if (book.oldPrice && book.oldPrice > book.price) {
        discountPercent = Math.round(((book.oldPrice - book.price) / book.oldPrice) * 100);
    }
    
    // Book card content
    card.innerHTML = `
        <div class="relative">
            <img src="${book.imageUrl || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80'}" 
                alt="${book.title}" 
                class="w-full h-64 object-cover">
            
            ${discountPercent ? `
                <div class="book-discount-badge">
                    -${discountPercent}%
                </div>
            ` : ''}
            
            ${rank ? `
                <div class="absolute top-3 left-3 bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center font-bold">
                    ${rank}
                </div>
            ` : ''}
        </div>
        
        <div class="p-4 flex-grow flex flex-col">
            <div class="mb-2">
                ${createStarRating(book.rating || 4)}
            </div>
            
            <h3 class="font-bold text-lg mb-2 line-clamp-2">${book.title}</h3>
            <p class="text-gray-600 mb-2">${book.author}</p>
            
            <div class="mt-auto pt-4">
                <div class="flex items-baseline">
                    <span class="text-lg font-bold text-primary">${formatCurrency(book.price)}</span>
                    
                    ${book.oldPrice ? `
                        <span class="ml-2 old-price">${formatCurrency(book.oldPrice)}</span>
                    ` : ''}
                </div>
                
                <button class="btn btn-primary w-full mt-3 add-to-cart-btn" data-book-id="${book.id}">
                    Ajouter au panier
                </button>
            </div>
        </div>
    `;
    
    // Add event listener to the Add to Cart button
    const addToCartBtn = card.querySelector('.add-to-cart-btn');
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const bookId = parseInt(addToCartBtn.getAttribute('data-book-id'));
            addToCart(bookId);
            showToast(`"${book.title}" ajouté au panier`, 'success');
        });
    }
    
    return card;
}

/**
 * Create a category card element
 * @param {Object} category - The category data
 * @returns {HTMLElement} The category card element
 */
function createCategoryCard(category) {
    const card = document.createElement('a');
    card.href = `catalogue.html?category=${category.id}`;
    card.className = 'category-card block relative h-36 rounded-lg overflow-hidden';
    
    // Category card background (we use gradient overlay + image)
    card.style.backgroundImage = `url('${category.imageUrl || 'https://images.unsplash.com/photo-1512820790803-83ca734da794?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2574&q=80'}')`;
    card.style.backgroundSize = 'cover';
    card.style.backgroundPosition = 'center';
    
    // Category card content
    card.innerHTML = `
        <div class="category-card-content">
            <h3 class="text-white font-bold text-lg">${category.name}</h3>
        </div>
    `;
    
    return card;
}

/**
 * Simulate fetching books from an API
 * @param {boolean} featured - Whether to fetch featured books
 * @param {boolean} bestseller - Whether to fetch bestseller books
 * @returns {Promise<Array>} A promise that resolves to an array of books
 */
async function fetchBooks(featured = false, bestseller = false) {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Sample book data
    // In a real app, this would be fetched from an API
    const sampleBooks = [
        {
            id: 1,
            title: "L'Art de la Guerre",
            author: "Sun Tzu",
            description: "Un classique de la stratégie militaire qui a inspiré de nombreux leaders à travers l'histoire.",
            price: 14.99,
            oldPrice: null,
            imageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
            categoryId: 3,
            featured: true,
            bestSeller: true,
            rating: 4.8
        },
        {
            id: 2,
            title: "Le Petit Prince",
            author: "Antoine de Saint-Exupéry",
            description: "Une histoire poétique qui aborde les thèmes de l'amour, l'amitié et le sens de la vie.",
            price: 12.50,
            oldPrice: 15.99,
            imageUrl: "https://images.unsplash.com/photo-1629992101753-56d196c8aabb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=690&q=80",
            categoryId: 1,
            featured: true,
            bestSeller: true,
            rating: 4.9
        },
        {
            id: 3,
            title: "Sapiens: Une brève histoire de l'humanité",
            author: "Yuval Noah Harari",
            description: "Une exploration de l'histoire humaine et de comment nous en sommes arrivés là.",
            price: 22.90,
            oldPrice: null,
            imageUrl: "https://images.unsplash.com/photo-1491841550275-ad7854e35ca6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80",
            categoryId: 2,
            featured: true,
            bestSeller: false,
            rating: 4.7
        },
        {
            id: 4,
            title: "Harry Potter à l'école des sorciers",
            author: "J.K. Rowling",
            description: "Le premier tome de la célèbre série qui a captivé des millions de lecteurs dans le monde.",
            price: 19.99,
            oldPrice: 24.99,
            imageUrl: "https://images.unsplash.com/photo-1551269901-5c5e14c25df7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2669&q=80",
            categoryId: 4,
            featured: true,
            bestSeller: true,
            rating: 4.9
        },
        {
            id: 5,
            title: "Les Misérables",
            author: "Victor Hugo",
            description: "Un chef-d'œuvre de la littérature française qui explore la justice, la politique et l'amour.",
            price: 17.50,
            oldPrice: null,
            imageUrl: "https://images.unsplash.com/photo-1629992101753-56d196c8aabb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=690&q=80",
            categoryId: 1,
            featured: false,
            bestSeller: true,
            rating: 4.6
        },
        {
            id: 6,
            title: "L'Alchimiste",
            author: "Paulo Coelho",
            description: "Une fable qui inspire à suivre ses rêves et à trouver sa légende personnelle.",
            price: 11.90,
            oldPrice: 14.90,
            imageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
            categoryId: 5,
            featured: false,
            bestSeller: true,
            rating: 4.5
        }
    ];
    
    // Filter books based on parameters
    if (featured) {
        return sampleBooks.filter(book => book.featured);
    } else if (bestseller) {
        return sampleBooks.filter(book => book.bestSeller);
    } else {
        return sampleBooks;
    }
}

/**
 * Simulate fetching categories from an API
 * @returns {Promise<Array>} A promise that resolves to an array of categories
 */
async function fetchCategories() {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 600));
    
    // Sample category data
    // In a real app, this would be fetched from an API
    return [
        {
            id: 1,
            name: "Romans",
            icon: "book",
            imageUrl: "https://images.unsplash.com/photo-1512820790803-83ca734da794?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2574&q=80"
        },
        {
            id: 2,
            name: "Histoire",
            icon: "landmark",
            imageUrl: "https://images.unsplash.com/photo-1461360228754-6e81c478b882?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2274&q=80"
        },
        {
            id: 3,
            name: "Philosophie",
            icon: "brain",
            imageUrl: "https://images.unsplash.com/photo-1544396821-4dd40b938ad3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2233&q=80"
        },
        {
            id: 4,
            name: "Science Fiction",
            icon: "rocket",
            imageUrl: "https://images.unsplash.com/photo-1532012197267-da84d127e765?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80"
        }
    ];
}