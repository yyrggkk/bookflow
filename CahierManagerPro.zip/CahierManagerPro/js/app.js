/**
 * BibliothèquePlus Main JavaScript
 * Handles common functionality across the site
 */

// DOM Elements
const cartCountElement = document.getElementById('cart-count');
const authButton = document.getElementById('auth-button');
const languageSelector = document.getElementById('language-selector');
const newsletterForm = document.getElementById('newsletter-form');
const searchForm = document.querySelector('.search-form');

// Configuration
const API_URL = 'php/api';

// User authentication state
let currentUser = null;

/**
 * Initialize the application
 */
document.addEventListener('DOMContentLoaded', () => {
    // Check if user is logged in
    checkAuthStatus();
    
    // Initialize cart
    updateCartCount();
    
    // Set up event listeners
    setupEventListeners();
    
    // Add toast container to body if it doesn't exist
    if (!document.querySelector('.toast-container')) {
        const toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container';
        document.body.appendChild(toastContainer);
    }
});

/**
 * Set up global event listeners
 */
function setupEventListeners() {
    // Language selector
    if (languageSelector) {
        languageSelector.addEventListener('change', (e) => {
            // Save language preference to localStorage
            localStorage.setItem('preferredLanguage', e.target.value);
            // In a real app, this would reload the page with the new language
            showToast('Langue changée avec succès', 'success');
        });
    }
    
    // Newsletter form
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const emailInput = newsletterForm.querySelector('input[type="email"]');
            if (emailInput && emailInput.value) {
                // In a real app, this would submit to a newsletter API
                showToast('Merci de vous être inscrit à notre newsletter!', 'success');
                emailInput.value = '';
            }
        });
    }
    
    // Search form
    if (searchForm) {
        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const searchInput = searchForm.querySelector('input');
            if (searchInput && searchInput.value) {
                window.location.href = `catalogue.html?search=${encodeURIComponent(searchInput.value)}`;
            }
        });
    }
}

/**
 * Check user authentication status
 */
function checkAuthStatus() {
    // Try to get user data from localStorage
    const userData = localStorage.getItem('user');
    
    if (userData) {
        try {
            currentUser = JSON.parse(userData);
            updateAuthUI(true);
        } catch (e) {
            console.error('Error parsing user data:', e);
            localStorage.removeItem('user');
            updateAuthUI(false);
        }
    } else {
        updateAuthUI(false);
    }
    
    // In a real app, we would also validate the session with the server
    // This is just a simulation for the frontend
}

/**
 * Update UI based on authentication status
 */
function updateAuthUI(isLoggedIn) {
    if (!authButton) return;
    
    if (isLoggedIn && currentUser) {
        // User is logged in
        authButton.innerHTML = `
            <span class="d-none d-md-inline">Mon compte</span>
            <i class="fas fa-user-circle d-inline d-md-none"></i>
        `;
        authButton.href = 'profile.html';
        
        // Add dropdown for user menu (if not already present)
        if (!document.getElementById('user-dropdown')) {
            const dropdown = document.createElement('div');
            dropdown.id = 'user-dropdown';
            dropdown.className = 'dropdown';
            
            authButton.parentNode.replaceChild(dropdown, authButton);
            
            dropdown.innerHTML = `
                <button class="btn btn-primary py-2 px-4 rounded dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <span class="d-none d-md-inline">${currentUser.username}</span>
                    <i class="fas fa-user-circle d-inline d-md-none"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item" href="profile.html">Mon profil</a></li>
                    <li><a class="dropdown-item" href="orders.html">Mes commandes</a></li>
                    ${currentUser.role === 'seller' ? '<li><a class="dropdown-item" href="seller-dashboard.html">Tableau de bord vendeur</a></li>' : ''}
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="#" id="logout-button">Déconnexion</a></li>
                </ul>
            `;
            
            // Add event listener for logout
            document.getElementById('logout-button').addEventListener('click', (e) => {
                e.preventDefault();
                logout();
            });
        }
    } else {
        // User is not logged in
        authButton.textContent = 'Se connecter';
        authButton.href = 'auth.html';
        
        // If there's a dropdown, replace it with the auth button
        const dropdown = document.getElementById('user-dropdown');
        if (dropdown) {
            dropdown.parentNode.replaceChild(authButton, dropdown);
        }
    }
}

/**
 * Update cart count from localStorage
 */
function updateCartCount() {
    if (!cartCountElement) return;
    
    let count = 0;
    const cart = getCart();
    
    // Sum quantities of all items in cart
    if (cart && cart.length > 0) {
        count = cart.reduce((sum, item) => sum + item.quantity, 0);
    }
    
    cartCountElement.textContent = count;
}

/**
 * Add item to cart
 * @param {number} bookId - The ID of the book
 * @param {number} quantity - Quantity to add
 */
function addToCart(bookId, quantity = 1) {
    // Get current cart
    let cart = getCart();
    
    // Find if the item already exists in cart
    const existingItemIndex = cart.findIndex(item => item.bookId === bookId);
    
    if (existingItemIndex >= 0) {
        // Update quantity if item already exists
        cart[existingItemIndex].quantity += quantity;
    } else {
        // Add new item
        cart.push({
            bookId,
            quantity
        });
    }
    
    // Save cart
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Update cart count with animation
    updateCartCount();
    cartCountElement.classList.add('pulse');
    setTimeout(() => {
        cartCountElement.classList.remove('pulse');
    }, 500);
    
    return cart;
}

/**
 * Get cart from localStorage
 * @returns {Array} Cart items array
 */
function getCart() {
    try {
        const cart = localStorage.getItem('cart');
        return cart ? JSON.parse(cart) : [];
    } catch (e) {
        console.error('Error getting cart from localStorage:', e);
        return [];
    }
}

/**
 * Remove item from cart
 * @param {number} bookId - The ID of the book to remove
 */
function removeFromCart(bookId) {
    let cart = getCart();
    cart = cart.filter(item => item.bookId !== bookId);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    return cart;
}

/**
 * Update item quantity in cart
 * @param {number} bookId - The ID of the book
 * @param {number} quantity - New quantity
 */
function updateCartItemQuantity(bookId, quantity) {
    if (quantity <= 0) {
        return removeFromCart(bookId);
    }
    
    let cart = getCart();
    const itemIndex = cart.findIndex(item => item.bookId === bookId);
    
    if (itemIndex >= 0) {
        cart[itemIndex].quantity = quantity;
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartCount();
    }
    
    return cart;
}

/**
 * Clear the cart
 */
function clearCart() {
    localStorage.removeItem('cart');
    updateCartCount();
}

/**
 * Logout the user
 */
function logout() {
    // Clear user data
    localStorage.removeItem('user');
    currentUser = null;
    
    // Update UI
    updateAuthUI(false);
    
    // Show success message
    showToast('Déconnexion réussie', 'success');
    
    // Redirect to home page
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 1000);
}

/**
 * Show a toast notification
 * @param {string} message - The message to display
 * @param {string} type - The type of toast (success, error, info, warning)
 */
function showToast(message, type = 'info') {
    const toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) return;
    
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast show bg-${type === 'success' ? 'success' : type === 'error' ? 'danger' : type === 'warning' ? 'warning' : 'info'} text-white`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="toast-header bg-${type === 'success' ? 'success' : type === 'error' ? 'danger' : type === 'warning' ? 'warning' : 'info'} text-white">
            <strong class="me-auto">
                ${type === 'success' ? '<i class="fas fa-check-circle"></i> Succès' : 
                type === 'error' ? '<i class="fas fa-exclamation-circle"></i> Erreur' : 
                type === 'warning' ? '<i class="fas fa-exclamation-triangle"></i> Attention' : 
                '<i class="fas fa-info-circle"></i> Information'}
            </strong>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body">
            ${message}
        </div>
    `;
    
    // Add to container
    toastContainer.appendChild(toast);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toastContainer.removeChild(toast);
        }, 300);
    }, 5000);
    
    // Add close button functionality
    const closeButton = toast.querySelector('.btn-close');
    if (closeButton) {
        closeButton.addEventListener('click', () => {
            toast.classList.remove('show');
            setTimeout(() => {
                toastContainer.removeChild(toast);
            }, 300);
        });
    }
}

/**
 * Format currency for display
 * @param {number} amount - The amount to format
 * @param {string} currency - The currency code (default: EUR)
 * @returns {string} Formatted currency string
 */
function formatCurrency(amount, currency = 'EUR') {
    return new Intl.NumberFormat('fr-FR', { 
        style: 'currency', 
        currency 
    }).format(amount);
}

/**
 * Format date for display
 * @param {string|Date} date - The date to format
 * @returns {string} Formatted date string
 */
function formatDate(date) {
    return new Intl.DateTimeFormat('fr-FR', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    }).format(new Date(date));
}

/**
 * Create star rating HTML
 * @param {number} rating - The rating (0-5)
 * @returns {string} HTML for star rating
 */
function createStarRating(rating) {
    rating = Math.round(rating * 2) / 2; // Round to nearest 0.5
    
    let html = '<div class="star-rating">';
    
    // Add full stars
    for (let i = 1; i <= Math.floor(rating); i++) {
        html += '<i class="fas fa-star"></i>';
    }
    
    // Add half star if needed
    if (rating % 1 !== 0) {
        html += '<i class="fas fa-star-half-alt"></i>';
    }
    
    // Add empty stars
    for (let i = Math.ceil(rating); i < 5; i++) {
        html += '<i class="far fa-star"></i>';
    }
    
    html += '</div>';
    return html;
}

/**
 * Validate form inputs
 * @param {HTMLFormElement} form - The form to validate
 * @returns {boolean} Whether the form is valid
 */
function validateForm(form) {
    const inputs = form.querySelectorAll('input, select, textarea');
    let isValid = true;
    
    inputs.forEach(input => {
        if (input.hasAttribute('required') && !input.value.trim()) {
            isValid = false;
            input.classList.add('is-invalid');
            
            // Create feedback message if it doesn't exist
            let feedback = input.nextElementSibling;
            if (!feedback || !feedback.classList.contains('invalid-feedback')) {
                feedback = document.createElement('div');
                feedback.className = 'invalid-feedback';
                input.parentNode.insertBefore(feedback, input.nextElementSibling);
            }
            
            feedback.textContent = 'Ce champ est obligatoire';
        } else if (input.type === 'email' && input.value && !isValidEmail(input.value)) {
            isValid = false;
            input.classList.add('is-invalid');
            
            let feedback = input.nextElementSibling;
            if (!feedback || !feedback.classList.contains('invalid-feedback')) {
                feedback = document.createElement('div');
                feedback.className = 'invalid-feedback';
                input.parentNode.insertBefore(feedback, input.nextElementSibling);
            }
            
            feedback.textContent = 'Veuillez entrer une adresse email valide';
        } else {
            input.classList.remove('is-invalid');
        }
    });
    
    return isValid;
}

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean} Whether the email is valid
 */
function isValidEmail(email) {
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(String(email).toLowerCase());
}