import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useLocation, useSearch, Link, Redirect } from "wouter";
import { insertUserSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Footer } from "@/components/footer";
import { Header } from "@/components/header";
import { LoadingSpinner } from "@/components/ui/loading";

// Login schema (simplified version of user schema)
const loginSchema = z.object({
  username: z.string().min(3, "Le nom d'utilisateur doit contenir au moins 3 caractères"),
  password: z.string().min(6, "Le mot de passe doit contenir au moins 6 caractères"),
});

// Extended user schema with validation
const registerSchema = insertUserSchema.extend({
  password: z.string().min(6, "Le mot de passe doit contenir au moins 6 caractères"),
  confirmPassword: z.string(),
  acceptTerms: z.boolean().refine(val => val === true, {
    message: "Vous devez accepter les conditions d'utilisation",
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: "Les mots de passe ne correspondent pas",
  path: ["confirmPassword"],
});

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [location, setLocation] = useLocation();
  
  // Parse query parameters
  const search = useSearch();
  const params = new URLSearchParams(search);
  const action = params.get("action") || "login";
  const isSeller = params.get("seller") === "true";
  
  const [activeTab, setActiveTab] = useState(action);

  // Login form
  const loginForm = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Register form with seller option
  const registerForm = useForm({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      fullName: "",
      role: isSeller ? "seller" : "buyer",
      address: "",
      phone: "",
      acceptTerms: false,
    },
  });

  // Set the role when isSeller changes
  useEffect(() => {
    registerForm.setValue("role", isSeller ? "seller" : "buyer");
  }, [isSeller, registerForm]);

  // Handle tab changes
  useEffect(() => {
    setActiveTab(action);
  }, [action]);

  // Redirect if user is already logged in
  if (user) {
    return <Redirect to="/" />;
  }

  const onLoginSubmit = (data: z.infer<typeof loginSchema>) => {
    loginMutation.mutate(data);
  };

  const onRegisterSubmit = (data: z.infer<typeof registerSchema>) => {
    // Remove confirmPassword and acceptTerms from data before submitting
    const { confirmPassword, acceptTerms, ...userData } = data;
    registerMutation.mutate(userData);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-50 py-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-8 items-start max-w-6xl mx-auto">
            {/* Left Column - Auth Forms */}
            <div className="w-full md:w-1/2">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-8">
                  <TabsTrigger value="login">Connexion</TabsTrigger>
                  <TabsTrigger value="register">Inscription</TabsTrigger>
                </TabsList>
                
                <TabsContent value="login">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-2xl font-serif">Connexion</CardTitle>
                      <CardDescription>
                        Connectez-vous à votre compte pour accéder à votre bibliothèque
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Form {...loginForm}>
                        <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                          <FormField
                            control={loginForm.control}
                            name="username"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Nom d'utilisateur</FormLabel>
                                <FormControl>
                                  <Input placeholder="Entrez votre nom d'utilisateur" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={loginForm.control}
                            name="password"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Mot de passe</FormLabel>
                                <FormControl>
                                  <Input type="password" placeholder="Entrez votre mot de passe" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <div className="flex justify-between items-center">
                            <div className="flex items-center space-x-2">
                              <Checkbox id="remember" />
                              <label htmlFor="remember" className="text-sm text-gray-600 cursor-pointer">
                                Se souvenir de moi
                              </label>
                            </div>
                            <a href="#" className="text-sm text-primary hover:underline">
                              Mot de passe oublié?
                            </a>
                          </div>
                          <Button 
                            type="submit" 
                            className="w-full" 
                            disabled={loginMutation.isPending}
                          >
                            {loginMutation.isPending ? (
                              <><LoadingSpinner size="small" className="mr-2" /> Connexion...</>
                            ) : (
                              "Se connecter"
                            )}
                          </Button>
                        </form>
                      </Form>
                    </CardContent>
                    <CardFooter className="flex justify-center border-t pt-6">
                      <p className="text-sm text-gray-600">
                        Pas encore de compte?{" "}
                        <Link 
                          href={isSeller ? "/auth?action=register&seller=true" : "/auth?action=register"}
                          className="text-primary hover:underline"
                        >
                          S'inscrire maintenant
                        </Link>
                      </p>
                    </CardFooter>
                  </Card>
                </TabsContent>
                
                <TabsContent value="register">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-2xl font-serif">
                        {isSeller ? "Inscription vendeur" : "Inscription"}
                      </CardTitle>
                      <CardDescription>
                        {isSeller 
                          ? "Créez un compte vendeur pour commencer à vendre vos livres" 
                          : "Créez un compte pour commencer à acheter des livres"}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Form {...registerForm}>
                        <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField
                              control={registerForm.control}
                              name="username"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Nom d'utilisateur</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Choisissez un nom d'utilisateur" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={registerForm.control}
                              name="email"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Email</FormLabel>
                                  <FormControl>
                                    <Input type="email" placeholder="Entrez votre email" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <FormField
                            control={registerForm.control}
                            name="fullName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Nom complet</FormLabel>
                                <FormControl>
                                  <Input placeholder="Entrez votre nom complet" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField
                              control={registerForm.control}
                              name="password"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Mot de passe</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="password" 
                                      placeholder="Créez un mot de passe" 
                                      {...field}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={registerForm.control}
                              name="confirmPassword"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Confirmer le mot de passe</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="password" 
                                      placeholder="Confirmez votre mot de passe" 
                                      {...field}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          {isSeller && (
                            <>
                              <FormField
                                control={registerForm.control}
                                name="address"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Adresse</FormLabel>
                                    <FormControl>
                                      <Input 
                                        placeholder="Entrez votre adresse complète" 
                                        {...field}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={registerForm.control}
                                name="phone"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Téléphone</FormLabel>
                                    <FormControl>
                                      <Input 
                                        placeholder="Entrez votre numéro de téléphone" 
                                        {...field}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </>
                          )}
                          
                          <FormField
                            control={registerForm.control}
                            name="acceptTerms"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox 
                                    checked={field.value} 
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>
                                    J'accepte les <a href="#" className="text-primary hover:underline">conditions d'utilisation</a> et la <a href="#" className="text-primary hover:underline">politique de confidentialité</a>
                                  </FormLabel>
                                  <FormMessage />
                                </div>
                              </FormItem>
                            )}
                          />
                          
                          <Button 
                            type="submit" 
                            className="w-full" 
                            disabled={registerMutation.isPending}
                          >
                            {registerMutation.isPending ? (
                              <><LoadingSpinner size="small" className="mr-2" /> Inscription en cours...</>
                            ) : (
                              "S'inscrire"
                            )}
                          </Button>
                        </form>
                      </Form>
                    </CardContent>
                    <CardFooter className="flex justify-center border-t pt-6">
                      <p className="text-sm text-gray-600">
                        Déjà un compte?{" "}
                        <Link 
                          href={isSeller ? "/auth?action=login&seller=true" : "/auth?action=login"}
                          className="text-primary hover:underline"
                        >
                          Se connecter
                        </Link>
                      </p>
                    </CardFooter>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
            
            {/* Right Column - Hero */}
            <div className="w-full md:w-1/2 bg-primary text-white rounded-lg overflow-hidden shadow-lg">
              <div className="p-8 md:p-12">
                <h2 className="text-3xl font-serif font-bold mb-4">
                  {isSeller 
                    ? "Vendez vos livres sur BibliothèquePlus" 
                    : "Bienvenue sur BibliothèquePlus"}
                </h2>
                <p className="mb-6">
                  {isSeller 
                    ? "Rejoignez notre communauté de vendeurs et atteignez des milliers de lecteurs passionnés à la recherche de leur prochaine lecture."
                    : "La plus grande marketplace française dédiée aux livres neufs et d'occasion. Trouvez votre prochaine lecture parmi des milliers de titres."}
                </p>
                
                <div className="space-y-4 mt-8">
                  <div className="flex items-start space-x-3">
                    <div className="bg-white rounded-full p-1 text-primary">✓</div>
                    <div>
                      <h3 className="font-medium">
                        {isSeller ? "Créez votre librairie en ligne" : "Accès à des milliers de livres"}
                      </h3>
                      <p className="text-sm text-white/80">
                        {isSeller 
                          ? "Gérez facilement votre inventaire et vos ventes"
                          : "Romans, essais, livres pour enfants, et bien plus encore"}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="bg-white rounded-full p-1 text-primary">✓</div>
                    <div>
                      <h3 className="font-medium">
                        {isSeller ? "Touchez une large audience" : "Prix compétitifs"}
                      </h3>
                      <p className="text-sm text-white/80">
                        {isSeller 
                          ? "Des milliers de lecteurs à la recherche de leur prochaine lecture"
                          : "Comparez les offres de différents vendeurs pour le meilleur prix"}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="bg-white rounded-full p-1 text-primary">✓</div>
                    <div>
                      <h3 className="font-medium">
                        {isSeller ? "Paiements sécurisés" : "Livraison rapide et sécurisée"}
                      </h3>
                      <p className="text-sm text-white/80">
                        {isSeller 
                          ? "Recevez vos paiements rapidement et en toute sécurité"
                          : "Recevez vos livres directement chez vous"}
                      </p>
                    </div>
                  </div>
                </div>
                
                {!isSeller && (
                  <div className="mt-8 pt-6 border-t border-white/20">
                    <p className="font-medium mb-2">Vous êtes un vendeur ?</p>
                    <Button 
                      variant="secondary"
                      asChild
                    >
                      <Link href="/auth?seller=true">
                        Créer un compte vendeur
                      </Link>
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
