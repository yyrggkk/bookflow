import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Order } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { LoadingPage, LoadingSection } from "@/components/ui/loading";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { AlertCircle, Package, ShoppingBag, Eye } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function OrdersPage() {
  const { user, isLoading: isLoadingUser } = useAuth();
  const [filterStatus, setFilterStatus] = useState<string | null>(null);

  // Fetch user orders
  const {
    data: orders = [],
    isLoading: isLoadingOrders,
  } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
    enabled: !!user,
  });

  // Filter orders based on selected status
  const filteredOrders = filterStatus
    ? orders.filter(order => order.status === filterStatus)
    : orders;

  if (isLoadingUser) {
    return <LoadingPage />;
  }

  if (!user) {
    return (
      <div>
        <Header />
        <div className="container mx-auto px-4 py-12 text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-4">Accès refusé</h1>
          <p className="mb-6">Vous devez être connecté pour accéder à cette page.</p>
          <Button asChild>
            <Link href="/auth">Se connecter</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-serif font-bold mb-2">Mes commandes</h1>
          <p className="text-gray-600 mb-6">Suivi et historique de vos commandes</p>
          
          <Tabs defaultValue="all" onValueChange={(value) => setFilterStatus(value === "all" ? null : value)}>
            <TabsList className="mb-6">
              <TabsTrigger value="all">Toutes</TabsTrigger>
              <TabsTrigger value="pending">En attente</TabsTrigger>
              <TabsTrigger value="processing">En traitement</TabsTrigger>
              <TabsTrigger value="shipped">Expédiées</TabsTrigger>
              <TabsTrigger value="delivered">Livrées</TabsTrigger>
              <TabsTrigger value="cancelled">Annulées</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all">
              {renderOrdersTable(filteredOrders, isLoadingOrders)}
            </TabsContent>
            <TabsContent value="pending">
              {renderOrdersTable(filteredOrders, isLoadingOrders)}
            </TabsContent>
            <TabsContent value="processing">
              {renderOrdersTable(filteredOrders, isLoadingOrders)}
            </TabsContent>
            <TabsContent value="shipped">
              {renderOrdersTable(filteredOrders, isLoadingOrders)}
            </TabsContent>
            <TabsContent value="delivered">
              {renderOrdersTable(filteredOrders, isLoadingOrders)}
            </TabsContent>
            <TabsContent value="cancelled">
              {renderOrdersTable(filteredOrders, isLoadingOrders)}
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

function renderOrdersTable(orders: Order[], isLoading: boolean) {
  if (isLoading) {
    return <LoadingSection />;
  }

  if (orders.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 flex flex-col items-center justify-center">
          <div className="bg-gray-100 p-4 rounded-full mb-4">
            <ShoppingBag className="h-12 w-12 text-gray-400" />
          </div>
          <h3 className="text-xl font-medium mb-2">Aucune commande trouvée</h3>
          <p className="text-gray-500 mb-6 text-center">
            Vous n'avez pas encore de commandes correspondant à ce filtre.
          </p>
          <Button asChild>
            <Link href="/catalog">Continuer vos achats</Link>
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle>Liste des commandes</CardTitle>
        <CardDescription>
          {orders.length} commande{orders.length !== 1 ? "s" : ""}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Commande</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Montant</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Livraison</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">
                    #{order.id}
                  </TableCell>
                  <TableCell>
                    {new Date(order.createdAt).toLocaleDateString('fr-FR')}
                  </TableCell>
                  <TableCell>{order.totalAmount.toFixed(2)} €</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        order.status === "delivered"
                          ? "bg-green-50 text-green-700 border-green-200"
                          : order.status === "shipped"
                          ? "bg-blue-50 text-blue-700 border-blue-200"
                          : order.status === "processing"
                          ? "bg-amber-50 text-amber-700 border-amber-200"
                          : order.status === "cancelled"
                          ? "bg-red-50 text-red-700 border-red-200"
                          : "bg-gray-50 text-gray-700 border-gray-200"
                      }
                    >
                      {order.status === "delivered"
                        ? "Livré"
                        : order.status === "shipped"
                        ? "Expédié"
                        : order.status === "processing"
                        ? "En traitement"
                        : order.status === "cancelled"
                        ? "Annulé"
                        : "En attente"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Package className="h-4 w-4 mr-1 text-gray-500" />
                      <span className="text-sm">
                        {order.status === "delivered"
                          ? "Livré le " + new Date(new Date(order.createdAt).getTime() + 432000000).toLocaleDateString('fr-FR')
                          : order.status === "shipped"
                          ? "Expédié le " + new Date(new Date(order.createdAt).getTime() + 86400000).toLocaleDateString('fr-FR')
                          : order.status === "processing"
                          ? "En préparation"
                          : order.status === "cancelled"
                          ? "Annulé"
                          : "En attente de traitement"}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button asChild variant="outline" size="sm">
                      <Link href={`/orders/${order.id}`}>
                        <Eye className="h-4 w-4 mr-1" />
                        Détails
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
