import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { LoadingPage, LoadingSpinner } from "@/components/ui/loading";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { AlertCircle, User, Edit, Check } from "lucide-react";
import { Link } from "wouter";

// Profile update schema
const profileUpdateSchema = z.object({
  fullName: z.string().min(3, "Le nom complet est requis"),
  email: z.string().email("Email invalide"),
  phone: z.string().optional(),
  address: z.string().optional(),
});

type ProfileUpdateFormValues = z.infer<typeof profileUpdateSchema>;

// Password update schema
const passwordUpdateSchema = z.object({
  currentPassword: z.string().min(1, "Le mot de passe actuel est requis"),
  newPassword: z.string().min(6, "Le nouveau mot de passe doit avoir au moins 6 caractères"),
  confirmPassword: z.string().min(6, "La confirmation du mot de passe est requise"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Les mots de passe ne correspondent pas",
  path: ["confirmPassword"],
});

type PasswordUpdateFormValues = z.infer<typeof passwordUpdateSchema>;

export default function ProfilePage() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");
  const [isEditing, setIsEditing] = useState(false);

  // Initialize profile form
  const profileForm = useForm<ProfileUpdateFormValues>({
    resolver: zodResolver(profileUpdateSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      email: user?.email || "",
      phone: user?.phone || "",
      address: user?.address || "",
    },
  });

  // Initialize password form
  const passwordForm = useForm<PasswordUpdateFormValues>({
    resolver: zodResolver(passwordUpdateSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileUpdateFormValues) => {
      const res = await apiRequest("PUT", "/api/user", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Profil mis à jour",
        description: "Vos informations ont été mises à jour avec succès.",
      });
      setIsEditing(false);
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur s'est produite lors de la mise à jour du profil.",
        variant: "destructive",
      });
    },
  });

  // Update password mutation
  const updatePasswordMutation = useMutation({
    mutationFn: async (data: PasswordUpdateFormValues) => {
      const res = await apiRequest("PUT", "/api/user/password", {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Mot de passe mis à jour",
        description: "Votre mot de passe a été mis à jour avec succès.",
      });
      passwordForm.reset({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur s'est produite lors de la mise à jour du mot de passe.",
        variant: "destructive",
      });
    },
  });

  // Handle profile form submission
  const onProfileSubmit = (data: ProfileUpdateFormValues) => {
    // Note: In a real application, this would call the API
    // For this demo, we'll just show a success message
    toast({
      title: "Fonctionnalité en développement",
      description: "La mise à jour du profil sera disponible prochainement.",
    });
    setIsEditing(false);
  };

  // Handle password form submission
  const onPasswordSubmit = (data: PasswordUpdateFormValues) => {
    // Note: In a real application, this would call the API
    // For this demo, we'll just show a success message
    toast({
      title: "Fonctionnalité en développement",
      description: "La mise à jour du mot de passe sera disponible prochainement.",
    });
    passwordForm.reset();
  };

  if (isLoading) {
    return <LoadingPage />;
  }

  if (!user) {
    return (
      <div>
        <Header />
        <div className="container mx-auto px-4 py-12 text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-4">Accès refusé</h1>
          <p className="mb-6">Vous devez être connecté pour accéder à cette page.</p>
          <Button asChild>
            <Link href="/auth">Se connecter</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-serif font-bold mb-6">Mon Profil</h1>
            
            <div className="flex flex-col md:flex-row gap-8">
              {/* User overview card */}
              <div className="w-full md:w-1/3">
                <Card>
                  <CardContent className="pt-6 text-center">
                    <Avatar className="h-24 w-24 mx-auto mb-4">
                      <AvatarFallback className="bg-primary text-white text-xl">
                        {user.fullName ? user.fullName.charAt(0).toUpperCase() : "U"}
                      </AvatarFallback>
                    </Avatar>
                    <h2 className="text-xl font-medium">{user.fullName || user.username}</h2>
                    <p className="text-gray-500 mb-4">{user.email}</p>
                    
                    <div className="flex justify-center gap-2">
                      <Button 
                        variant="outline" 
                        className="text-xs"
                        onClick={() => {
                          setActiveTab("profile");
                          setIsEditing(true);
                        }}
                      >
                        <Edit size={14} className="mr-1" />
                        Modifier profil
                      </Button>
                    </div>
                    
                    <div className="mt-6 pt-6 border-t border-gray-200 text-left">
                      <h3 className="font-medium mb-3">Liens rapides</h3>
                      <ul className="space-y-2 text-sm">
                        <li>
                          <Link href="/orders" className="text-primary hover:underline">
                            Mes commandes
                          </Link>
                        </li>
                        {user.role === "seller" && (
                          <li>
                            <Link href="/seller-dashboard" className="text-primary hover:underline">
                              Tableau de bord vendeur
                            </Link>
                          </li>
                        )}
                        <li>
                          <a href="#" className="text-primary hover:underline">
                            Livres favoris
                          </a>
                        </li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* User details */}
              <div className="w-full md:w-2/3">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="w-full grid grid-cols-2">
                    <TabsTrigger value="profile">Informations</TabsTrigger>
                    <TabsTrigger value="security">Sécurité</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="profile" className="mt-4">
                    <Card>
                      <CardHeader>
                        <div className="flex justify-between items-center">
                          <div>
                            <CardTitle>Informations personnelles</CardTitle>
                            <CardDescription>
                              Gérez vos informations de profil
                            </CardDescription>
                          </div>
                          {!isEditing && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setIsEditing(true)}
                            >
                              <Edit size={16} className="mr-2" />
                              Modifier
                            </Button>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent>
                        {isEditing ? (
                          <Form {...profileForm}>
                            <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                              <FormField
                                control={profileForm.control}
                                name="fullName"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Nom complet</FormLabel>
                                    <FormControl>
                                      <Input {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={profileForm.control}
                                name="email"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Email</FormLabel>
                                    <FormControl>
                                      <Input {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={profileForm.control}
                                name="phone"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Téléphone</FormLabel>
                                    <FormControl>
                                      <Input {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={profileForm.control}
                                name="address"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Adresse</FormLabel>
                                    <FormControl>
                                      <Input {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </form>
                          </Form>
                        ) : (
                          <dl className="divide-y divide-gray-100">
                            <div className="grid grid-cols-3 py-3">
                              <dt className="text-sm font-medium text-gray-500">Nom d'utilisateur</dt>
                              <dd className="col-span-2 text-sm">{user.username}</dd>
                            </div>
                            <div className="grid grid-cols-3 py-3">
                              <dt className="text-sm font-medium text-gray-500">Nom complet</dt>
                              <dd className="col-span-2 text-sm">{user.fullName || "-"}</dd>
                            </div>
                            <div className="grid grid-cols-3 py-3">
                              <dt className="text-sm font-medium text-gray-500">Email</dt>
                              <dd className="col-span-2 text-sm">{user.email}</dd>
                            </div>
                            <div className="grid grid-cols-3 py-3">
                              <dt className="text-sm font-medium text-gray-500">Téléphone</dt>
                              <dd className="col-span-2 text-sm">{user.phone || "-"}</dd>
                            </div>
                            <div className="grid grid-cols-3 py-3">
                              <dt className="text-sm font-medium text-gray-500">Adresse</dt>
                              <dd className="col-span-2 text-sm">{user.address || "-"}</dd>
                            </div>
                            <div className="grid grid-cols-3 py-3">
                              <dt className="text-sm font-medium text-gray-500">Type de compte</dt>
                              <dd className="col-span-2 text-sm">
                                {user.role === "seller" ? "Vendeur" : "Acheteur"}
                              </dd>
                            </div>
                          </dl>
                        )}
                      </CardContent>
                      {isEditing && (
                        <CardFooter className="flex justify-end space-x-2">
                          <Button
                            variant="outline"
                            onClick={() => {
                              profileForm.reset({
                                fullName: user.fullName || "",
                                email: user.email,
                                phone: user.phone || "",
                                address: user.address || "",
                              });
                              setIsEditing(false);
                            }}
                          >
                            Annuler
                          </Button>
                          <Button
                            type="submit"
                            onClick={profileForm.handleSubmit(onProfileSubmit)}
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending ? (
                              <>
                                <LoadingSpinner size="small" className="mr-2" />
                                Enregistrement...
                              </>
                            ) : (
                              <>
                                <Check size={16} className="mr-2" />
                                Enregistrer
                              </>
                            )}
                          </Button>
                        </CardFooter>
                      )}
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="security" className="mt-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>Changer le mot de passe</CardTitle>
                        <CardDescription>
                          Mettez à jour votre mot de passe pour sécuriser votre compte
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Form {...passwordForm}>
                          <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
                            <FormField
                              control={passwordForm.control}
                              name="currentPassword"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Mot de passe actuel</FormLabel>
                                  <FormControl>
                                    <Input type="password" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={passwordForm.control}
                              name="newPassword"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Nouveau mot de passe</FormLabel>
                                  <FormControl>
                                    <Input type="password" {...field} />
                                  </FormControl>
                                  <FormDescription>
                                    Au moins 6 caractères
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={passwordForm.control}
                              name="confirmPassword"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Confirmer le mot de passe</FormLabel>
                                  <FormControl>
                                    <Input type="password" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <Button
                              type="submit"
                              className="mt-2"
                              disabled={updatePasswordMutation.isPending}
                            >
                              {updatePasswordMutation.isPending ? (
                                <>
                                  <LoadingSpinner size="small" className="mr-2" />
                                  Mise à jour...
                                </>
                              ) : (
                                "Mettre à jour le mot de passe"
                              )}
                            </Button>
                          </form>
                        </Form>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
