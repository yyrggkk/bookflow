import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Book } from "@shared/schema";
import { useRoute, Link } from "wouter";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { StarRating } from "@/components/ui/star-rating";
import { useCart } from "@/hooks/use-cart";
import { LoadingPage, LoadingSpinner } from "@/components/ui/loading";
import { Heart, ArrowLeft, Plus, Minus, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BookCard } from "@/components/book-card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";

export default function BookDetailPage() {
  const [, params] = useRoute("/books/:id");
  const bookId = params?.id ? parseInt(params.id) : null;
  const [quantity, setQuantity] = useState(1);
  const [isFavorite, setIsFavorite] = useState(false);
  const { addToCart } = useCart();

  // Fetch book details
  const {
    data: book,
    isLoading,
    error,
  } = useQuery<Book>({
    queryKey: [`/api/books/${bookId}`],
    enabled: !!bookId,
  });

  // Fetch similar books (books in the same category)
  const { data: similarBooks = [] } = useQuery<Book[]>({
    queryKey: [book ? `/api/books?categoryId=${book.categoryId}` : null],
    enabled: !!book,
  });

  // Filter out the current book from similar books and limit to 5
  const filteredSimilarBooks = similarBooks
    .filter((similarBook) => similarBook.id !== book?.id)
    .slice(0, 5);

  const handleQuantityChange = (amount: number) => {
    const newQuantity = Math.max(1, quantity + amount);
    setQuantity(newQuantity);
  };

  const handleAddToCart = () => {
    if (book) {
      addToCart(book.id, quantity);
    }
  };

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite);
  };

  if (isLoading) {
    return <LoadingPage />;
  }

  if (error || !book) {
    return (
      <div>
        <Header />
        <div className="container mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold mb-4">Livre non trouvé</h1>
          <p className="mb-6">Le livre que vous recherchez n'existe pas ou a été retiré.</p>
          <Button asChild>
            <Link href="/catalog">Retour au catalogue</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-grow bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          {/* Breadcrumb navigation */}
          <nav className="flex items-center text-sm mb-6">
            <Link href="/" className="text-gray-500 hover:text-primary">
              Accueil
            </Link>
            <span className="mx-2 text-gray-400">/</span>
            <Link href="/catalog" className="text-gray-500 hover:text-primary">
              Catalogue
            </Link>
            <span className="mx-2 text-gray-400">/</span>
            <span className="text-gray-900 font-medium">{book.title}</span>
          </nav>

          {/* Back button (mobile) */}
          <Button
            variant="ghost"
            size="sm"
            asChild
            className="mb-4 md:hidden"
          >
            <Link href="/catalog">
              <ArrowLeft size={16} className="mr-2" />
              Retour au catalogue
            </Link>
          </Button>

          {/* Book details section */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="flex flex-col md:flex-row">
              {/* Book image */}
              <div className="md:w-1/3 lg:w-1/4 relative">
                <div className="aspect-[3/4] bg-gray-100">
                  <img
                    src={book.imageUrl || "https://images.unsplash.com/photo-1544947950-fa07a98d237f"}
                    alt={`Couverture de ${book.title}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                {book.discount && (
                  <div className="absolute top-4 left-4 bg-secondary text-white text-xs font-bold uppercase py-1 px-3 rounded">
                    -{book.discount}%
                  </div>
                )}
                <Button
                  variant="outline"
                  size="icon"
                  className={cn(
                    "absolute top-4 right-4 bg-white rounded-full",
                    isFavorite ? "text-secondary border-secondary" : ""
                  )}
                  onClick={toggleFavorite}
                >
                  <Heart
                    size={20}
                    className={isFavorite ? "fill-secondary text-secondary" : ""}
                  />
                </Button>
              </div>

              {/* Book info */}
              <div className="p-6 md:w-2/3 lg:w-3/4">
                <div className="flex flex-col lg:flex-row lg:justify-between">
                  <div className="lg:w-2/3">
                    <h1 className="text-2xl md:text-3xl font-serif font-bold mb-2">
                      {book.title}
                    </h1>
                    <p className="text-lg text-gray-600 mb-3">par {book.author}</p>

                    <div className="flex items-center mb-6">
                      <StarRating rating={book.rating} reviews={book.numReviews} className="mr-4" />
                      {book.stock > 0 ? (
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          En stock
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                          Indisponible
                        </Badge>
                      )}
                    </div>

                    <div className="mb-6">
                      <p className="text-gray-700 text-sm leading-relaxed">
                        {book.description}
                      </p>
                    </div>
                  </div>

                  <div className="lg:w-1/3 lg:pl-8 mt-6 lg:mt-0 lg:border-l lg:border-gray-200">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <span className="text-2xl font-bold text-primary-dark">
                            {book.price.toFixed(2)} €
                          </span>
                          {book.oldPrice && (
                            <span className="ml-2 text-gray-500 line-through">
                              {book.oldPrice.toFixed(2)} €
                            </span>
                          )}
                        </div>
                        {book.discount && (
                          <Badge variant="default" className="bg-secondary">
                            Économisez {book.discount}%
                          </Badge>
                        )}
                      </div>

                      {book.stock > 0 ? (
                        <>
                          <div className="flex items-center justify-between mb-4">
                            <span className="text-sm font-medium">Quantité:</span>
                            <div className="flex items-center border border-gray-300 rounded-md">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 rounded-none"
                                onClick={() => handleQuantityChange(-1)}
                                disabled={quantity <= 1}
                              >
                                <Minus size={16} />
                              </Button>
                              <span className="w-8 text-center">{quantity}</span>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 rounded-none"
                                onClick={() => handleQuantityChange(1)}
                                disabled={quantity >= book.stock}
                              >
                                <Plus size={16} />
                              </Button>
                            </div>
                          </div>

                          <Button
                            onClick={handleAddToCart}
                            className="w-full mb-2"
                          >
                            <ShoppingCart size={18} className="mr-2" />
                            Ajouter au panier
                          </Button>

                          <p className="text-xs text-gray-500 text-center">
                            {book.stock} exemplaire{book.stock !== 1 ? "s" : ""} disponible{book.stock !== 1 ? "s" : ""}
                          </p>
                        </>
                      ) : (
                        <div className="text-center py-2">
                          <p className="text-red-600 font-medium mb-2">Actuellement indisponible</p>
                          <Button disabled className="w-full opacity-70">
                            Indisponible
                          </Button>
                        </div>
                      )}
                    </div>

                    <div className="mt-4 text-sm text-gray-600">
                      <p className="flex items-center mb-2">
                        <span className="mr-2">📦</span>
                        Livraison sous 2-4 jours ouvrés
                      </p>
                      <p className="flex items-center mb-2">
                        <span className="mr-2">🔒</span>
                        Paiement sécurisé
                      </p>
                      <p className="flex items-center">
                        <span className="mr-2">↩️</span>
                        Retours acceptés sous 14 jours
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Tabs section */}
            <div className="border-t border-gray-200 p-6">
              <Tabs defaultValue="details">
                <TabsList className="w-full md:w-auto">
                  <TabsTrigger value="details">Détails</TabsTrigger>
                  <TabsTrigger value="reviews">Avis ({book.numReviews})</TabsTrigger>
                  <TabsTrigger value="shipping">Livraison & Retours</TabsTrigger>
                </TabsList>
                <TabsContent value="details" className="py-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-medium mb-2">Détails du livre</h3>
                      <ul className="space-y-2 text-sm">
                        <li className="flex justify-between">
                          <span className="text-gray-600">Auteur</span>
                          <span className="font-medium">{book.author}</span>
                        </li>
                        <Separator />
                        <li className="flex justify-between">
                          <span className="text-gray-600">Catégorie</span>
                          <span className="font-medium">
                            <Link
                              href={`/catalog?category=${book.categoryId}`}
                              className="text-primary hover:underline"
                            >
                              {
                                {
                                  1: "Romans",
                                  2: "Sciences Humaines",
                                  3: "Science-Fiction",
                                  4: "Jeunesse",
                                  5: "Histoire",
                                }[book.categoryId] || "Autre"
                              }
                            </Link>
                          </span>
                        </li>
                        <Separator />
                        <li className="flex justify-between">
                          <span className="text-gray-600">Vendeur</span>
                          <span className="font-medium">Vendeur ID: {book.sellerId}</span>
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="font-medium mb-2">Résumé du livre</h3>
                      <p className="text-sm text-gray-700 leading-relaxed">
                        {book.description}
                      </p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="reviews" className="py-4">
                  <div className="space-y-6">
                    <div className="flex items-center">
                      <div className="mr-4">
                        <div className="text-3xl font-bold">{book.rating.toFixed(1)}</div>
                        <StarRating rating={book.rating} showReviews={false} size="md" />
                        <p className="text-sm text-gray-500 mt-1">{book.numReviews} avis</p>
                      </div>
                      <div className="flex-grow">
                        <div className="text-center bg-gray-100 p-4 rounded-lg">
                          <p className="mb-2">Aucun avis disponible pour le moment.</p>
                          <Button variant="outline" size="sm" disabled>
                            Écrire un avis
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="shipping" className="py-4">
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-medium mb-2">Livraison</h3>
                      <p className="text-sm text-gray-700 mb-4">
                        Nous proposons plusieurs options de livraison pour répondre à vos besoins :
                      </p>
                      <ul className="list-disc pl-5 space-y-2 text-sm text-gray-700">
                        <li>Livraison standard : 2-4 jours ouvrés (3,99€)</li>
                        <li>Livraison express : 1-2 jours ouvrés (6,99€)</li>
                        <li>Livraison gratuite pour les commandes supérieures à 35€</li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="font-medium mb-2">Politique de retour</h3>
                      <p className="text-sm text-gray-700 mb-4">
                        Vous n'êtes pas satisfait de votre achat ? Voici notre politique de retour :
                      </p>
                      <ul className="list-disc pl-5 space-y-2 text-sm text-gray-700">
                        <li>Les retours sont acceptés dans les 14 jours suivant la réception</li>
                        <li>Les articles doivent être retournés dans leur état d'origine</li>
                        <li>Les frais de retour sont à la charge du client sauf en cas d'erreur de notre part</li>
                      </ul>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>

          {/* Similar books section */}
          {filteredSimilarBooks.length > 0 && (
            <section className="mt-12">
              <h2 className="text-2xl font-serif font-bold mb-6">Vous aimerez aussi</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
                {filteredSimilarBooks.map((similarBook) => (
                  <BookCard key={similarBook.id} book={similarBook} />
                ))}
              </div>
            </section>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
