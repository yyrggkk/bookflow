import { useEffect } from "react";
import { useCart } from "@/hooks/use-cart";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { LoadingSection, LoadingSpinner } from "@/components/ui/loading";
import { Plus, Minus, Trash2, ShoppingCart } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

export default function CartPage() {
  const { cartItems, isLoading, updateQuantity, removeFromCart, totalPrice } = useCart();

  // Set page title
  useEffect(() => {
    document.title = "Panier | BibliothèquePlus";
  }, []);

  // Render empty cart state
  const renderEmptyCart = () => (
    <div className="text-center py-16">
      <div className="bg-gray-100 w-24 h-24 mx-auto mb-6 rounded-full flex items-center justify-center">
        <ShoppingCart size={32} className="text-gray-400" />
      </div>
      <h2 className="text-2xl font-bold mb-2">Votre panier est vide</h2>
      <p className="text-gray-600 mb-8">
        Vous n'avez pas encore ajouté d'articles à votre panier.
      </p>
      <Button asChild size="lg">
        <Link href="/catalog">
          Découvrir le catalogue
        </Link>
      </Button>
    </div>
  );

  // Render cart items
  const renderCartItems = () => (
    <div className="space-y-4">
      {cartItems.map((item) => (
        <div key={item.id} className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100">
          <div className="flex flex-col sm:flex-row p-4">
            <div className="w-full sm:w-24 h-24 mr-4 mb-4 sm:mb-0 flex-shrink-0">
              <img 
                src={item.book.imageUrl || "https://images.unsplash.com/photo-1544947950-fa07a98d237f"} 
                alt={item.book.title} 
                className="w-full h-full object-cover rounded"
              />
            </div>
            <div className="flex-grow mr-4">
              <Link href={`/books/${item.book.id}`} className="font-medium hover:text-primary">
                {item.book.title}
              </Link>
              <p className="text-sm text-gray-600 mb-2">par {item.book.author}</p>
              <p className="text-sm text-gray-500">
                Stock disponible: {item.book.stock}
              </p>
            </div>
            <div className="flex flex-row sm:flex-col justify-between items-end mt-4 sm:mt-0">
              <div className="flex items-center border border-gray-300 rounded-md">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 rounded-none"
                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                  disabled={item.quantity <= 1}
                >
                  <Minus size={16} />
                </Button>
                <span className="w-8 text-center">{item.quantity}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 rounded-none"
                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  disabled={item.quantity >= item.book.stock}
                >
                  <Plus size={16} />
                </Button>
              </div>
              <div className="flex flex-col items-end">
                <span className="font-bold">{(item.book.price * item.quantity).toFixed(2)} €</span>
                <span className="text-xs text-gray-500">
                  {item.quantity} x {item.book.price.toFixed(2)} €
                </span>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-4 py-2 flex justify-between">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-red-600 hover:text-red-700 hover:bg-red-50 -ml-2"
              onClick={() => removeFromCart(item.id)}
            >
              <Trash2 size={16} className="mr-1" />
              Supprimer
            </Button>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-serif font-bold mb-6">Votre Panier</h1>
          
          {isLoading ? (
            <LoadingSection />
          ) : cartItems.length === 0 ? (
            renderEmptyCart()
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                {renderCartItems()}
              </div>
              
              <div className="lg:col-span-1">
                <Card className="sticky top-4">
                  <CardHeader>
                    <CardTitle>Résumé de la commande</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-600">
                        Sous-total ({cartItems.reduce((acc, item) => acc + item.quantity, 0)} articles)
                      </span>
                      <span>{totalPrice.toFixed(2)} €</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Frais de livraison</span>
                      <span>
                        {totalPrice >= 35 ? (
                          <span className="text-green-600">Gratuit</span>
                        ) : (
                          "3,99 €"
                        )}
                      </span>
                    </div>
                    {totalPrice < 35 && (
                      <div className="text-sm text-gray-600 bg-blue-50 p-2 rounded">
                        Ajoutez {(35 - totalPrice).toFixed(2)} € d'articles pour bénéficier de la livraison gratuite.
                      </div>
                    )}
                    <Separator />
                    <div className="flex justify-between font-bold">
                      <span>Total</span>
                      <span>
                        {totalPrice >= 35
                          ? totalPrice.toFixed(2)
                          : (totalPrice + 3.99).toFixed(2)}{" "}
                        €
                      </span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button asChild className="w-full">
                      <Link href="/checkout">
                        Passer à la caisse
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
                
                <div className="mt-4 bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                  <h3 className="font-medium mb-2">Méthodes de paiement acceptées</h3>
                  <div className="flex space-x-2">
                    <div className="bg-gray-100 p-1 rounded w-10 h-7"></div>
                    <div className="bg-gray-100 p-1 rounded w-10 h-7"></div>
                    <div className="bg-gray-100 p-1 rounded w-10 h-7"></div>
                    <div className="bg-gray-100 p-1 rounded w-10 h-7"></div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
