import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Book, Order, insertBookSchema } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { LoadingPage, LoadingSection } from "@/components/ui/loading";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  AlertCircle, 
  MoreVertical, 
  Edit, 
  Trash2, 
  PlusCircle, 
  Layers, 
  Package, 
  ShoppingCart,
  TrendingUp,
  DollarSign,
  Users
} from "lucide-react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

// Extended book schema with client-side validation
const bookFormSchema = insertBookSchema.extend({
  imageUrl: z.string().url("URL d'image invalide").or(z.literal("")),
});

type BookFormValues = z.infer<typeof bookFormSchema>;

export default function SellerDashboard() {
  const { user, isLoading: isLoadingUser } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [isAddBookDialogOpen, setIsAddBookDialogOpen] = useState(false);

  // Fetch categories
  const { data: categories = [] } = useQuery({
    queryKey: ["/api/categories"],
  });

  // Fetch seller's books
  const {
    data: sellerBooks = [],
    isLoading: isLoadingBooks,
    refetch: refetchBooks,
  } = useQuery<Book[]>({
    queryKey: ["/api/books"],
    enabled: !!user,
  });

  // Fetch seller's orders
  const {
    data: sellerOrders = [],
    isLoading: isLoadingOrders,
  } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
    enabled: !!user && user.role === "seller",
  });

  // Initialize book form
  const bookForm = useForm<BookFormValues>({
    resolver: zodResolver(bookFormSchema),
    defaultValues: {
      title: "",
      author: "",
      description: "",
      price: 0,
      oldPrice: undefined,
      imageUrl: "",
      categoryId: 1,
      stock: 1,
      featured: false,
      bestSeller: false,
      discount: undefined,
    },
  });

  // Create book mutation
  const createBookMutation = useMutation({
    mutationFn: async (data: BookFormValues) => {
      const res = await apiRequest("POST", "/api/books", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Livre ajouté",
        description: "Le livre a été ajouté avec succès.",
      });
      bookForm.reset();
      setIsAddBookDialogOpen(false);
      refetchBooks();
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur s'est produite lors de l'ajout du livre.",
        variant: "destructive",
      });
    },
  });

  // Update book mutation
  const updateBookMutation = useMutation({
    mutationFn: async (data: BookFormValues & { id: number }) => {
      const { id, ...bookData } = data;
      const res = await apiRequest("PUT", `/api/books/${id}`, bookData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Livre mis à jour",
        description: "Le livre a été mis à jour avec succès.",
      });
      setEditingBook(null);
      setIsAddBookDialogOpen(false);
      refetchBooks();
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur s'est produite lors de la mise à jour du livre.",
        variant: "destructive",
      });
    },
  });

  // Delete book mutation
  const deleteBookMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/books/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Livre supprimé",
        description: "Le livre a été supprimé avec succès.",
      });
      refetchBooks();
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur s'est produite lors de la suppression du livre.",
        variant: "destructive",
      });
    },
  });

  // Update order status mutation
  const updateOrderStatusMutation = useMutation({
    mutationFn: async ({ orderId, status }: { orderId: number; status: string }) => {
      const res = await apiRequest("PUT", `/api/orders/${orderId}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Statut mis à jour",
        description: "Le statut de la commande a été mis à jour avec succès.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur s'est produite lors de la mise à jour du statut.",
        variant: "destructive",
      });
    },
  });

  // Handle book form submission
  const onBookSubmit = (data: BookFormValues) => {
    if (editingBook) {
      updateBookMutation.mutate({ ...data, id: editingBook.id });
    } else {
      createBookMutation.mutate(data);
    }
  };

  // Set form values when editing a book
  useEffect(() => {
    if (editingBook) {
      bookForm.reset({
        title: editingBook.title,
        author: editingBook.author,
        description: editingBook.description,
        price: editingBook.price,
        oldPrice: editingBook.oldPrice,
        imageUrl: editingBook.imageUrl,
        categoryId: editingBook.categoryId,
        stock: editingBook.stock,
        featured: editingBook.featured,
        bestSeller: editingBook.bestSeller,
        discount: editingBook.discount,
      });
    }
  }, [editingBook, bookForm]);

  // Calculate dashboard statistics
  const totalBooks = sellerBooks.length;
  const totalOrders = sellerOrders.length;
  const totalRevenue = sellerOrders.reduce((sum, order) => sum + order.totalAmount, 0);
  const pendingOrders = sellerOrders.filter(order => order.status === "pending").length;

  if (isLoadingUser) {
    return <LoadingPage />;
  }

  if (!user || user.role !== "seller") {
    return (
      <div>
        <Header />
        <div className="container mx-auto px-4 py-12 text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-4">Accès refusé</h1>
          <p className="mb-6">Vous devez être un vendeur pour accéder à cette page.</p>
          <Button asChild>
            <Link href="/">Retour à l'accueil</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-serif font-bold mb-2">Tableau de bord vendeur</h1>
          <p className="text-gray-600 mb-6">Gérez vos livres, suivez vos commandes et analysez vos ventes</p>
          
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full grid grid-cols-4">
              <TabsTrigger value="overview">Vue d'ensemble</TabsTrigger>
              <TabsTrigger value="books">Mes livres</TabsTrigger>
              <TabsTrigger value="orders">Commandes</TabsTrigger>
              <TabsTrigger value="settings">Paramètres</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="bg-blue-100 p-3 rounded-lg mr-4">
                        <Layers className="text-blue-600 h-6 w-6" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Livres en vente</p>
                        <h3 className="text-2xl font-bold">{totalBooks}</h3>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="bg-green-100 p-3 rounded-lg mr-4">
                        <DollarSign className="text-green-600 h-6 w-6" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Revenus totaux</p>
                        <h3 className="text-2xl font-bold">{totalRevenue.toFixed(2)} €</h3>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="bg-purple-100 p-3 rounded-lg mr-4">
                        <Package className="text-purple-600 h-6 w-6" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Commandes totales</p>
                        <h3 className="text-2xl font-bold">{totalOrders}</h3>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="bg-amber-100 p-3 rounded-lg mr-4">
                        <ShoppingCart className="text-amber-600 h-6 w-6" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Commandes en attente</p>
                        <h3 className="text-2xl font-bold">{pendingOrders}</h3>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Dernières commandes</CardTitle>
                    <CardDescription>
                      Aperçu des commandes récentes
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingOrders ? (
                      <LoadingSection />
                    ) : sellerOrders.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-gray-500">Aucune commande pour le moment</p>
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>ID</TableHead>
                              <TableHead>Date</TableHead>
                              <TableHead>Montant</TableHead>
                              <TableHead>Statut</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {sellerOrders.slice(0, 5).map((order) => (
                              <TableRow key={order.id}>
                                <TableCell className="font-medium">
                                  <Link href={`/orders/${order.id}`} className="text-primary hover:underline">
                                    #{order.id}
                                  </Link>
                                </TableCell>
                                <TableCell>
                                  {new Date(order.createdAt).toLocaleDateString()}
                                </TableCell>
                                <TableCell>{order.totalAmount.toFixed(2)} €</TableCell>
                                <TableCell>
                                  <Badge
                                    variant="outline"
                                    className={
                                      order.status === "delivered"
                                        ? "bg-green-50 text-green-700 border-green-200"
                                        : order.status === "shipped"
                                        ? "bg-blue-50 text-blue-700 border-blue-200"
                                        : order.status === "processing"
                                        ? "bg-amber-50 text-amber-700 border-amber-200"
                                        : order.status === "cancelled"
                                        ? "bg-red-50 text-red-700 border-red-200"
                                        : "bg-gray-50 text-gray-700 border-gray-200"
                                    }
                                  >
                                    {order.status === "delivered"
                                      ? "Livré"
                                      : order.status === "shipped"
                                      ? "Expédié"
                                      : order.status === "processing"
                                      ? "En traitement"
                                      : order.status === "cancelled"
                                      ? "Annulé"
                                      : "En attente"}
                                  </Badge>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/orders">Voir toutes les commandes</Link>
                    </Button>
                  </CardFooter>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Livres populaires</CardTitle>
                    <CardDescription>
                      Vos livres les plus vendus
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingBooks ? (
                      <LoadingSection />
                    ) : sellerBooks.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-gray-500">Aucun livre pour le moment</p>
                        <Button 
                          variant="outline" 
                          className="mt-4"
                          onClick={() => setIsAddBookDialogOpen(true)}
                        >
                          <PlusCircle size={16} className="mr-2" />
                          Ajouter un livre
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {sellerBooks
                          .sort((a, b) => b.rating - a.rating)
                          .slice(0, 5)
                          .map((book) => (
                            <div key={book.id} className="flex items-center gap-3">
                              <div className="w-10 h-14 bg-gray-100 flex-shrink-0">
                                <img
                                  src={book.imageUrl || "https://images.unsplash.com/photo-1544947950-fa07a98d237f"}
                                  alt={book.title}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="flex-grow">
                                <h4 className="font-medium text-sm truncate">
                                  <Link href={`/books/${book.id}`} className="hover:text-primary">
                                    {book.title}
                                  </Link>
                                </h4>
                                <p className="text-xs text-gray-500">{book.price.toFixed(2)} €</p>
                              </div>
                              <div className="flex items-center text-amber-500">
                                <TrendingUp size={16} />
                                <span className="text-xs ml-1">{book.rating.toFixed(1)}</span>
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="books" className="mt-6">
              <Card>
                <CardHeader>
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
                    <div>
                      <CardTitle>Mes livres</CardTitle>
                      <CardDescription>
                        Gérez votre catalogue de livres
                      </CardDescription>
                    </div>
                    <Button 
                      onClick={() => {
                        setEditingBook(null);
                        bookForm.reset();
                        setIsAddBookDialogOpen(true);
                      }}
                      className="mt-4 sm:mt-0"
                    >
                      <PlusCircle size={16} className="mr-2" />
                      Ajouter un livre
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {isLoadingBooks ? (
                    <LoadingSection />
                  ) : sellerBooks.length === 0 ? (
                    <div className="text-center py-8">
                      <h3 className="text-lg font-medium mb-2">Aucun livre dans votre catalogue</h3>
                      <p className="text-gray-500 mb-6">Commencez à ajouter des livres pour les vendre sur BibliothèquePlus</p>
                      <Button
                        onClick={() => {
                          setEditingBook(null);
                          bookForm.reset();
                          setIsAddBookDialogOpen(true);
                        }}
                      >
                        <PlusCircle size={16} className="mr-2" />
                        Ajouter votre premier livre
                      </Button>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Livre</TableHead>
                            <TableHead>Prix</TableHead>
                            <TableHead>Stock</TableHead>
                            <TableHead>Catégorie</TableHead>
                            <TableHead>Statut</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {sellerBooks.map((book) => (
                            <TableRow key={book.id}>
                              <TableCell>
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-14 bg-gray-100 flex-shrink-0">
                                    <img
                                      src={book.imageUrl || "https://images.unsplash.com/photo-1544947950-fa07a98d237f"}
                                      alt={book.title}
                                      className="w-full h-full object-cover"
                                    />
                                  </div>
                                  <div>
                                    <div className="font-medium">
                                      <Link href={`/books/${book.id}`} className="hover:text-primary">
                                        {book.title}
                                      </Link>
                                    </div>
                                    <div className="text-sm text-gray-500">
                                      {book.author}
                                    </div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                {book.price.toFixed(2)} €
                                {book.oldPrice && (
                                  <span className="text-gray-500 line-through text-xs ml-1">
                                    {book.oldPrice.toFixed(2)} €
                                  </span>
                                )}
                              </TableCell>
                              <TableCell>
                                {book.stock > 0 ? book.stock : (
                                  <span className="text-red-500">Rupture</span>
                                )}
                              </TableCell>
                              <TableCell>
                                {categories.find(c => c.id === book.categoryId)?.name || ""}
                              </TableCell>
                              <TableCell>
                                <div className="flex flex-wrap gap-1">
                                  {book.featured && (
                                    <Badge variant="secondary" className="text-xs">
                                      Nouveau
                                    </Badge>
                                  )}
                                  {book.bestSeller && (
                                    <Badge variant="default" className="text-xs">
                                      Meilleure vente
                                    </Badge>
                                  )}
                                  {!book.featured && !book.bestSeller && (
                                    <Badge variant="outline" className="text-xs">
                                      Standard
                                    </Badge>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell className="text-right">
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="icon">
                                      <MoreVertical size={16} />
                                      <span className="sr-only">Actions</span>
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuItem
                                      onClick={() => {
                                        setEditingBook(book);
                                        setIsAddBookDialogOpen(true);
                                      }}
                                    >
                                      <Edit size={16} className="mr-2" />
                                      Modifier
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      className="text-red-600"
                                      onClick={() => {
                                        if (confirm("Êtes-vous sûr de vouloir supprimer ce livre ?")) {
                                          deleteBookMutation.mutate(book.id);
                                        }
                                      }}
                                    >
                                      <Trash2 size={16} className="mr-2" />
                                      Supprimer
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Dialog open={isAddBookDialogOpen} onOpenChange={setIsAddBookDialogOpen}>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>
                      {editingBook ? "Modifier un livre" : "Ajouter un livre"}
                    </DialogTitle>
                    <DialogDescription>
                      {editingBook
                        ? "Mettez à jour les informations de votre livre"
                        : "Ajoutez un nouveau livre à votre catalogue"}
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...bookForm}>
                    <form className="space-y-6" onSubmit={bookForm.handleSubmit(onBookSubmit)}>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-6">
                          <FormField
                            control={bookForm.control}
                            name="title"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Titre</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={bookForm.control}
                            name="author"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Auteur</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={bookForm.control}
                            name="categoryId"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Catégorie</FormLabel>
                                <Select
                                  value={field.value.toString()}
                                  onValueChange={(value) => field.onChange(parseInt(value))}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Sélectionnez une catégorie" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {categories.map((category) => (
                                      <SelectItem
                                        key={category.id}
                                        value={category.id.toString()}
                                      >
                                        {category.name}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={bookForm.control}
                              name="price"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Prix (€)</FormLabel>
                                  <FormControl>
                                    <Input
                                      type="number"
                                      min="0"
                                      step="0.01"
                                      {...field}
                                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={bookForm.control}
                              name="oldPrice"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Ancien prix (€)</FormLabel>
                                  <FormControl>
                                    <Input
                                      type="number"
                                      min="0"
                                      step="0.01"
                                      placeholder="Optionnel"
                                      {...field}
                                      value={field.value || ""}
                                      onChange={(e) => 
                                        field.onChange(
                                          e.target.value ? parseFloat(e.target.value) : undefined
                                        )
                                      }
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={bookForm.control}
                              name="stock"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Stock</FormLabel>
                                  <FormControl>
                                    <Input
                                      type="number"
                                      min="0"
                                      {...field}
                                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={bookForm.control}
                              name="discount"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Remise (%)</FormLabel>
                                  <FormControl>
                                    <Input
                                      type="number"
                                      min="0"
                                      max="100"
                                      placeholder="Optionnel"
                                      {...field}
                                      value={field.value || ""}
                                      onChange={(e) => 
                                        field.onChange(
                                          e.target.value ? parseInt(e.target.value) : undefined
                                        )
                                      }
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                        
                        <div className="space-y-6">
                          <FormField
                            control={bookForm.control}
                            name="imageUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>URL de l'image</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormDescription>
                                  Entrez l'URL d'une image pour votre livre
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={bookForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea
                                    {...field}
                                    className="min-h-[160px]"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="space-y-4 pt-2">
                            <FormField
                              control={bookForm.control}
                              name="featured"
                              render={({ field }) => (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value}
                                      onCheckedChange={field.onChange}
                                    />
                                  </FormControl>
                                  <div className="space-y-1 leading-none">
                                    <FormLabel>
                                      Marquer comme "Nouveauté"
                                    </FormLabel>
                                    <FormDescription>
                                      Ce livre sera affiché dans la section "Nouveautés"
                                    </FormDescription>
                                  </div>
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={bookForm.control}
                              name="bestSeller"
                              render={({ field }) => (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value}
                                      onCheckedChange={field.onChange}
                                    />
                                  </FormControl>
                                  <div className="space-y-1 leading-none">
                                    <FormLabel>
                                      Marquer comme "Meilleure vente"
                                    </FormLabel>
                                    <FormDescription>
                                      Ce livre sera affiché dans la section "Meilleures ventes"
                                    </FormDescription>
                                  </div>
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                      </div>
                      
                      <DialogFooter>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => {
                            setIsAddBookDialogOpen(false);
                            setEditingBook(null);
                          }}
                        >
                          Annuler
                        </Button>
                        <Button
                          type="submit"
                          disabled={createBookMutation.isPending || updateBookMutation.isPending}
                        >
                          {editingBook ? "Enregistrer les modifications" : "Ajouter le livre"}
                        </Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </TabsContent>
            
            <TabsContent value="orders" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Gestion des commandes</CardTitle>
                  <CardDescription>
                    Suivez et gérez vos commandes
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingOrders ? (
                    <LoadingSection />
                  ) : sellerOrders.length === 0 ? (
                    <div className="text-center py-8">
                      <h3 className="text-lg font-medium mb-2">Aucune commande pour le moment</h3>
                      <p className="text-gray-500">
                        Les commandes de vos clients apparaîtront ici
                      </p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>ID</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Client</TableHead>
                            <TableHead>Montant</TableHead>
                            <TableHead>Statut</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {sellerOrders.map((order) => (
                            <TableRow key={order.id}>
                              <TableCell className="font-medium">
                                <Link href={`/orders/${order.id}`} className="text-primary hover:underline">
                                  #{order.id}
                                </Link>
                              </TableCell>
                              <TableCell>
                                {new Date(order.createdAt).toLocaleDateString()}
                              </TableCell>
                              <TableCell>Client #{order.userId}</TableCell>
                              <TableCell>{order.totalAmount.toFixed(2)} €</TableCell>
                              <TableCell>
                                <Badge
                                  variant="outline"
                                  className={
                                    order.status === "delivered"
                                      ? "bg-green-50 text-green-700 border-green-200"
                                      : order.status === "shipped"
                                      ? "bg-blue-50 text-blue-700 border-blue-200"
                                      : order.status === "processing"
                                      ? "bg-amber-50 text-amber-700 border-amber-200"
                                      : order.status === "cancelled"
                                      ? "bg-red-50 text-red-700 border-red-200"
                                      : "bg-gray-50 text-gray-700 border-gray-200"
                                  }
                                >
                                  {order.status === "delivered"
                                    ? "Livré"
                                    : order.status === "shipped"
                                    ? "Expédié"
                                    : order.status === "processing"
                                    ? "En traitement"
                                    : order.status === "cancelled"
                                    ? "Annulé"
                                    : "En attente"}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-right">
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="icon">
                                      <MoreVertical size={16} />
                                      <span className="sr-only">Actions</span>
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuItem asChild>
                                      <Link href={`/orders/${order.id}`}>
                                        Voir les détails
                                      </Link>
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      disabled={order.status === "processing"}
                                      onClick={() => 
                                        updateOrderStatusMutation.mutate({
                                          orderId: order.id,
                                          status: "processing"
                                        })
                                      }
                                    >
                                      Marquer comme en traitement
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      disabled={order.status === "shipped"}
                                      onClick={() => 
                                        updateOrderStatusMutation.mutate({
                                          orderId: order.id,
                                          status: "shipped"
                                        })
                                      }
                                    >
                                      Marquer comme expédié
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      disabled={order.status === "delivered"}
                                      onClick={() => 
                                        updateOrderStatusMutation.mutate({
                                          orderId: order.id,
                                          status: "delivered"
                                        })
                                      }
                                    >
                                      Marquer comme livré
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      disabled={order.status === "cancelled"}
                                      onClick={() => 
                                        updateOrderStatusMutation.mutate({
                                          orderId: order.id,
                                          status: "cancelled"
                                        })
                                      }
                                      className="text-red-600"
                                    >
                                      Annuler la commande
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="settings" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Paramètres de vendeur</CardTitle>
                  <CardDescription>
                    Gérez les paramètres de votre compte vendeur
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-3">Informations du compte</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-gray-700">Nom d'utilisateur</label>
                          <p>{user.username}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-700">Email</label>
                          <p>{user.email}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-700">Nom complet</label>
                          <p>{user.fullName || "-"}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-700">Type de compte</label>
                          <p>Vendeur</p>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-lg font-medium mb-3">Coordonnées</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-gray-700">Adresse</label>
                          <p>{user.address || "-"}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-700">Téléphone</label>
                          <p>{user.phone || "-"}</p>
                        </div>
                      </div>
                      <Button 
                        variant="outline" 
                        className="mt-4"
                        asChild
                      >
                        <Link href="/profile">
                          <Edit size={16} className="mr-2" />
                          Modifier mon profil
                        </Link>
                      </Button>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-lg font-medium mb-3">Préférences de la boutique</h3>
                      <p className="text-gray-500 mb-4">
                        Les paramètres de la boutique seront disponibles prochainement.
                      </p>
                      <Button disabled>Configurer la boutique</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
