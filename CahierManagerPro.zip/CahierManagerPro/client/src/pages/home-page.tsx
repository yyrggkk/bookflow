import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Book, Category } from "@shared/schema";
import { Link } from "wouter";
import { BookCard } from "@/components/book-card";
import { CategoryCard } from "@/components/category-card";
import { BestsellerCard } from "@/components/bestseller-card";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { LoadingSection } from "@/components/ui/loading";
import { ChevronRight } from "lucide-react";

export default function HomePage() {
  // Fetch featured books
  const { 
    data: featuredBooks = [], 
    isLoading: isLoadingFeatured 
  } = useQuery<Book[]>({
    queryKey: ["/api/books?featured=true&limit=5"],
  });

  // Fetch bestseller books
  const { 
    data: bestsellerBooks = [], 
    isLoading: isLoadingBestsellers 
  } = useQuery<Book[]>({
    queryKey: ["/api/books?bestSeller=true&limit=4"],
  });

  // Fetch categories
  const { 
    data: categories = [], 
    isLoading: isLoadingCategories 
  } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative bg-primary-dark text-white">
          <div className="absolute inset-0 overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1507842217343-583bb7270b66?ixlib=rb-1.2.1&auto=format&fit=crop&w=1600&h=400&q=80" 
              alt="Bibliothèque de livres" 
              className="w-full h-full object-cover opacity-40"
            />
          </div>
          <div className="container mx-auto px-4 py-12 md:py-20 relative z-10">
            <div className="max-w-2xl">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-bold mb-4">
                Découvrez votre prochaine lecture préférée
              </h2>
              <p className="text-lg mb-8">
                Des milliers de livres à portée de clic. Trouvez les meilleures offres de nos vendeurs vérifiés.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-secondary hover:bg-secondary-light text-white">
                  <Link href="/catalog">
                    Explorer le catalogue
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="bg-white hover:bg-neutral-100 text-primary">
                  <Link href="/auth?seller=true">
                    Devenir vendeur
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
        
        {/* Featured Books Section */}
        <section className="container mx-auto px-4 py-10">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-serif font-bold">Nouveautés</h2>
            <Link href="/catalog?featured=true" className="text-primary hover:text-primary-dark font-medium flex items-center">
              Voir tout
              <ChevronRight size={16} className="ml-1" />
            </Link>
          </div>
          
          {isLoadingFeatured ? (
            <LoadingSection />
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
              {featuredBooks.map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>
          )}
        </section>
        
        {/* Categories Section */}
        <section className="bg-neutral-100 py-10">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-serif font-bold mb-6">Parcourir par catégorie</h2>
            
            {isLoadingCategories ? (
              <LoadingSection />
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {categories.map((category) => (
                  <CategoryCard key={category.id} category={category} />
                ))}
                <Link href="/catalog" className="bg-white rounded-lg shadow p-4 text-center hover:shadow-md transition duration-200">
                  <div className="text-3xl text-primary mb-2">📚</div>
                  <h3 className="font-medium">Toutes les catégories</h3>
                </Link>
              </div>
            )}
          </div>
        </section>

        {/* Bestsellers Section */}
        <section className="container mx-auto px-4 py-10">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-serif font-bold">Meilleures ventes</h2>
            <Link href="/catalog?bestseller=true" className="text-primary hover:text-primary-dark font-medium flex items-center">
              Voir tout
              <ChevronRight size={16} className="ml-1" />
            </Link>
          </div>
          
          {isLoadingBestsellers ? (
            <LoadingSection />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {bestsellerBooks.map((book, index) => (
                <BestsellerCard key={book.id} book={book} rank={index + 1} />
              ))}
            </div>
          )}
        </section>
        
        {/* Features Section */}
        <section className="bg-neutral-100 py-10">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-serif font-bold text-center mb-10">Pourquoi choisir BibliothèquePlus</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow p-6 text-center">
                <div className="bg-primary-light rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl text-white">✓</span>
                </div>
                <h3 className="text-xl font-medium mb-2">Vendeurs vérifiés</h3>
                <p className="text-neutral-600">Tous nos vendeurs sont vérifiés pour vous garantir une expérience d'achat sécurisée.</p>
              </div>
              
              <div className="bg-white rounded-lg shadow p-6 text-center">
                <div className="bg-primary-light rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl text-white">🚚</span>
                </div>
                <h3 className="text-xl font-medium mb-2">Livraison rapide</h3>
                <p className="text-neutral-600">Recevez vos livres rapidement grâce à notre réseau de distribution optimisé.</p>
              </div>
              
              <div className="bg-white rounded-lg shadow p-6 text-center">
                <div className="bg-primary-light rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl text-white">💬</span>
                </div>
                <h3 className="text-xl font-medium mb-2">Support client</h3>
                <p className="text-neutral-600">Notre équipe de support est disponible 7j/7 pour répondre à toutes vos questions.</p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Registration CTA */}
        <section className="container mx-auto px-4 py-12">
          <div className="bg-primary rounded-lg shadow-lg overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/2 p-8 md:p-12">
                <h2 className="text-2xl md:text-3xl font-serif font-bold text-white mb-4">Rejoignez notre communauté</h2>
                <p className="text-white text-opacity-90 mb-6">
                  Créez un compte pour profiter d'une expérience personnalisée, suivre vos commandes et recevoir des recommandations basées sur vos préférences.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild variant="default" className="bg-white text-primary hover:bg-neutral-100">
                    <Link href="/auth?action=register">
                      S'inscrire
                    </Link>
                  </Button>
                  <Button asChild variant="outline" className="border-white text-white hover:bg-white/10">
                    <Link href="/auth?action=login">
                      Se connecter
                    </Link>
                  </Button>
                </div>
              </div>
              <div className="md:w-1/2 bg-primary-dark p-8 md:p-12 flex items-center">
                <div>
                  <h3 className="text-xl md:text-2xl font-serif font-bold text-white mb-4">Vous êtes un vendeur ?</h3>
                  <p className="text-white text-opacity-90 mb-6">
                    Rejoignez notre marketplace et vendez vos livres à une large audience de lecteurs passionnés.
                  </p>
                  <Button asChild className="bg-secondary hover:bg-secondary-light text-white">
                    <Link href="/auth?seller=true">
                      Devenir vendeur
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
