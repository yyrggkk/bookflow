import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { LoadingSpinner } from "@/components/ui/loading";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";

const checkoutSchema = z.object({
  fullName: z.string().min(3, "Le nom complet est requis"),
  shippingAddress: z.string().min(10, "L'adresse de livraison est requise"),
  city: z.string().min(2, "La ville est requise"),
  postalCode: z.string().regex(/^\d{5}$/, "Code postal invalide (5 chiffres requis)"),
  country: z.string().min(2, "Le pays est requis"),
  email: z.string().email("Email invalide"),
  phone: z.string().regex(/^0[1-9]\d{8}$/, "Numéro de téléphone invalide"),
  paymentMethod: z.enum(["creditCard", "paypal", "bankTransfer"]),
  saveInformation: z.boolean().optional(),
});

type CheckoutFormValues = z.infer<typeof checkoutSchema>;

export default function CheckoutPage() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { cartItems, totalPrice, clearCart } = useCart();
  const { toast } = useToast();
  const [step, setStep] = useState(1);

  // Check if cart is empty, redirect if it is
  if (cartItems.length === 0) {
    setLocation("/cart");
    return null;
  }

  // Initialize form with user data if available
  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      shippingAddress: user?.address || "",
      city: "",
      postalCode: "",
      country: "France",
      email: user?.email || "",
      phone: user?.phone || "",
      paymentMethod: "creditCard",
      saveInformation: false,
    },
  });

  // Create order mutation
  const createOrderMutation = useMutation({
    mutationFn: async (data: CheckoutFormValues) => {
      // Prepare order data
      const orderData = {
        shippingAddress: `${data.shippingAddress}, ${data.city}, ${data.postalCode}, ${data.country}`,
        paymentMethod: data.paymentMethod,
      };
      
      const res = await apiRequest("POST", "/api/orders", orderData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Commande effectuée avec succès",
        description: "Votre commande a été traitée avec succès.",
      });
      clearCart();
      setLocation("/orders");
    },
    onError: (error) => {
      toast({
        title: "Erreur lors de la commande",
        description: error.message || "Une erreur s'est produite lors de la création de votre commande.",
        variant: "destructive",
      });
      // Go back to step 1 if there's an error
      setStep(1);
    },
  });

  const onSubmit = (data: CheckoutFormValues) => {
    if (step === 1) {
      setStep(2);
    } else {
      createOrderMutation.mutate(data);
    }
  };

  // Calculate shipping cost and total
  const shippingCost = totalPrice >= 35 ? 0 : 3.99;
  const finalTotal = totalPrice + shippingCost;

  // Render order summary
  const renderOrderSummary = () => (
    <Card>
      <CardHeader>
        <CardTitle>Résumé de la commande</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          {cartItems.map((item) => (
            <div key={item.id} className="flex justify-between text-sm">
              <span className="flex-grow">
                {item.book.title} <span className="text-gray-500">x{item.quantity}</span>
              </span>
              <span className="font-medium">
                {(item.book.price * item.quantity).toFixed(2)} €
              </span>
            </div>
          ))}
        </div>
        <Separator />
        <div className="flex justify-between">
          <span className="text-gray-600">Sous-total</span>
          <span>{totalPrice.toFixed(2)} €</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600">Frais de livraison</span>
          <span>
            {shippingCost === 0 ? (
              <span className="text-green-600">Gratuit</span>
            ) : (
              `${shippingCost.toFixed(2)} €`
            )}
          </span>
        </div>
        <Separator />
        <div className="flex justify-between font-bold">
          <span>Total</span>
          <span>{finalTotal.toFixed(2)} €</span>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-serif font-bold mb-2">Paiement</h1>
          <p className="text-gray-600 mb-6">
            Étape {step} sur 2: {step === 1 ? "Informations de livraison" : "Méthode de paiement"}
          </p>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>
                    {step === 1 ? "Informations de livraison" : "Méthode de paiement"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      {step === 1 ? (
                        <>
                          <FormField
                            control={form.control}
                            name="fullName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Nom complet</FormLabel>
                                <FormControl>
                                  <Input placeholder="Prénom Nom" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="email"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Email</FormLabel>
                                  <FormControl>
                                    <Input type="email" placeholder="votre@email.com" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="phone"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Téléphone</FormLabel>
                                  <FormControl>
                                    <Input placeholder="0612345678" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <FormField
                            control={form.control}
                            name="shippingAddress"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Adresse</FormLabel>
                                <FormControl>
                                  <Input placeholder="123 rue des Livres" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <FormField
                              control={form.control}
                              name="city"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Ville</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Paris" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="postalCode"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Code postal</FormLabel>
                                  <FormControl>
                                    <Input placeholder="75000" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="country"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Pays</FormLabel>
                                  <FormControl>
                                    <Input placeholder="France" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <FormField
                            control={form.control}
                            name="saveInformation"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0 mt-4">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>
                                    Sauvegarder ces informations pour mes prochains achats
                                  </FormLabel>
                                </div>
                              </FormItem>
                            )}
                          />
                        </>
                      ) : (
                        <FormField
                          control={form.control}
                          name="paymentMethod"
                          render={({ field }) => (
                            <FormItem className="space-y-3">
                              <FormLabel>Méthode de paiement</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="flex flex-col space-y-3"
                                >
                                  <FormItem className="flex items-center space-x-3 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="creditCard" />
                                    </FormControl>
                                    <FormLabel className="font-normal cursor-pointer">
                                      Carte de crédit
                                    </FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-3 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="paypal" />
                                    </FormControl>
                                    <FormLabel className="font-normal cursor-pointer">
                                      PayPal
                                    </FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-3 space-y-0">
                                    <FormControl>
                                      <RadioGroupItem value="bankTransfer" />
                                    </FormControl>
                                    <FormLabel className="font-normal cursor-pointer">
                                      Virement bancaire
                                    </FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                      
                      <div className="flex justify-between mt-6">
                        {step === 2 && (
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setStep(1)}
                          >
                            Retour
                          </Button>
                        )}
                        <Button
                          type="submit"
                          className={step === 1 ? "ml-auto" : ""}
                          disabled={createOrderMutation.isPending}
                        >
                          {createOrderMutation.isPending ? (
                            <>
                              <LoadingSpinner size="small" className="mr-2" />
                              Traitement...
                            </>
                          ) : step === 1 ? (
                            "Continuer vers le paiement"
                          ) : (
                            "Confirmer la commande"
                          )}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>
            
            <div className="lg:col-span-1">
              {renderOrderSummary()}
              
              <div className="mt-4 bg-white p-4 rounded-lg shadow-sm text-sm">
                <p className="mb-2">
                  En confirmant votre commande, vous acceptez nos{" "}
                  <a href="#" className="text-primary hover:underline">
                    conditions générales de vente
                  </a>
                  .
                </p>
                <p>
                  Vos données personnelles seront utilisées pour traiter votre commande, vous accompagner au cours de votre visite et pour d'autres raisons décrites dans notre{" "}
                  <a href="#" className="text-primary hover:underline">
                    politique de confidentialité
                  </a>
                  .
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
