import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useSearch } from "wouter";
import { Book, Category } from "@shared/schema";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { BookCard } from "@/components/book-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { LoadingSection } from "@/components/ui/loading";
import { Search, SlidersHorizontal, X } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

export default function CatalogPage() {
  const search = useSearch();
  const params = new URLSearchParams(search);
  
  // Get filters from URL
  const categoryParam = params.get("category");
  const searchParam = params.get("search");
  const featuredParam = params.get("featured");
  const bestsellerParam = params.get("bestseller");
  
  // State for filters
  const [searchTerm, setSearchTerm] = useState(searchParam || "");
  const [selectedCategory, setSelectedCategory] = useState<number | null>(
    categoryParam ? parseInt(categoryParam) : null
  );
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100]);
  const [showFilters, setShowFilters] = useState(false);
  
  // Fetch categories
  const { data: categories = [], isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Build query key based on filters
  let queryKey = "/api/books";
  const queryParams = [];
  
  if (featuredParam === "true") {
    queryParams.push("featured=true");
  }
  
  if (bestsellerParam === "true") {
    queryParams.push("bestSeller=true");
  }
  
  if (selectedCategory) {
    queryParams.push(`categoryId=${selectedCategory}`);
  }
  
  if (searchTerm) {
    queryParams.push(`search=${encodeURIComponent(searchTerm)}`);
  }
  
  if (queryParams.length > 0) {
    queryKey += "?" + queryParams.join("&");
  }
  
  // Fetch books
  const { data: books = [], isLoading: isLoadingBooks } = useQuery<Book[]>({
    queryKey: [queryKey],
  });
  
  // Filter books by price
  const filteredBooks = books.filter(
    (book) => book.price >= priceRange[0] && book.price <= priceRange[1]
  );
  
  // Handle search submit
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Update URL with search term
    const url = new URL(window.location.href);
    if (searchTerm) {
      url.searchParams.set("search", searchTerm);
    } else {
      url.searchParams.delete("search");
    }
    window.history.pushState({}, "", url.toString());
  };
  
  // Select category handler
  const handleCategoryChange = (categoryId: number) => {
    if (selectedCategory === categoryId) {
      setSelectedCategory(null);
      
      // Update URL to remove category
      const url = new URL(window.location.href);
      url.searchParams.delete("category");
      window.history.pushState({}, "", url.toString());
    } else {
      setSelectedCategory(categoryId);
      
      // Update URL with category
      const url = new URL(window.location.href);
      url.searchParams.set("category", categoryId.toString());
      window.history.pushState({}, "", url.toString());
    }
  };
  
  // Clear all filters
  const clearFilters = () => {
    setSearchTerm("");
    setSelectedCategory(null);
    setPriceRange([0, 100]);
    
    // Update URL to remove all filters
    const url = new URL(window.location.href);
    url.search = "";
    window.history.pushState({}, "", url.toString());
  };
  
  // Find max price for slider
  useEffect(() => {
    if (books.length > 0) {
      const maxPrice = Math.max(...books.map(book => book.price));
      setPriceRange([priceRange[0], Math.max(100, Math.ceil(maxPrice))]);
    }
  }, [books]);
  
  // Set page title based on filters
  useEffect(() => {
    let title = "Catalogue";
    
    if (featuredParam === "true") {
      title = "Nouveautés";
    } else if (bestsellerParam === "true") {
      title = "Meilleures ventes";
    } else if (selectedCategory) {
      const category = categories.find(c => c.id === selectedCategory);
      if (category) {
        title = category.name;
      }
    } else if (searchTerm) {
      title = `Résultats pour "${searchTerm}"`;
    }
    
    document.title = `${title} | BibliothèquePlus`;
  }, [featuredParam, bestsellerParam, selectedCategory, searchTerm, categories]);

  const FiltersContent = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-medium mb-3">Catégories</h3>
        <div className="space-y-2">
          {isLoadingCategories ? (
            <p>Chargement des catégories...</p>
          ) : (
            categories.map((category) => (
              <div key={category.id} className="flex items-center space-x-2">
                <Checkbox 
                  id={`category-${category.id}`}
                  checked={selectedCategory === category.id}
                  onCheckedChange={() => handleCategoryChange(category.id)}
                />
                <Label
                  htmlFor={`category-${category.id}`}
                  className="cursor-pointer"
                >
                  {category.name}
                </Label>
              </div>
            ))
          )}
        </div>
      </div>
      
      <Separator />
      
      <div>
        <h3 className="font-medium mb-3">Prix</h3>
        <div className="space-y-4">
          <Slider
            value={[priceRange[0], priceRange[1]]}
            min={0}
            max={Math.max(100, Math.ceil(Math.max(...books.map(book => book.price))))}
            step={1}
            onValueChange={(value) => setPriceRange([value[0], value[1]])}
            className="my-6"
          />
          <div className="flex items-center justify-between">
            <span>{priceRange[0].toFixed(2)} €</span>
            <span>{priceRange[1].toFixed(2)} €</span>
          </div>
        </div>
      </div>
      
      <Separator />
      
      <Button 
        variant="outline" 
        className="w-full" 
        onClick={clearFilters}
      >
        <X size={16} className="mr-2" />
        Effacer les filtres
      </Button>
    </div>
  );

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="mb-8 flex flex-col md:flex-row justify-between items-start gap-4">
            <div>
              <h1 className="text-3xl font-serif font-bold mb-2">
                {featuredParam === "true" ? "Nouveautés" : 
                bestsellerParam === "true" ? "Meilleures ventes" : 
                selectedCategory ? 
                  categories.find(c => c.id === selectedCategory)?.name || "Catalogue" : 
                searchTerm ? `Résultats pour "${searchTerm}"` : "Catalogue"}
              </h1>
              <p className="text-gray-600">
                {filteredBooks.length} livre{filteredBooks.length !== 1 ? "s" : ""} trouvé{filteredBooks.length !== 1 ? "s" : ""}
              </p>
            </div>
            
            <div className="w-full md:w-auto flex gap-2">
              <form 
                onSubmit={handleSearchSubmit} 
                className="relative flex-grow"
              >
                <Input
                  type="text"
                  placeholder="Rechercher des livres..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
                <Button
                  type="submit"
                  variant="ghost"
                  className="absolute right-0 top-0 h-full px-2"
                >
                  <Search size={18} />
                </Button>
              </form>
              
              <div className="md:hidden">
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="outline">
                      <SlidersHorizontal size={18} className="mr-2" />
                      Filtres
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left">
                    <SheetHeader>
                      <SheetTitle>Filtres</SheetTitle>
                    </SheetHeader>
                    <div className="py-4">
                      <FiltersContent />
                    </div>
                  </SheetContent>
                </Sheet>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row gap-8">
            {/* Filters - Desktop */}
            <div className="hidden md:block w-64 shrink-0">
              <div className="bg-white p-6 rounded-lg shadow">
                <h2 className="text-lg font-medium mb-4">Filtres</h2>
                <FiltersContent />
              </div>
            </div>
            
            {/* Books Grid */}
            <div className="flex-grow">
              {isLoadingBooks ? (
                <LoadingSection />
              ) : filteredBooks.length === 0 ? (
                <div className="bg-white p-8 rounded-lg shadow text-center">
                  <h3 className="text-xl font-medium mb-2">Aucun livre trouvé</h3>
                  <p className="text-gray-600 mb-4">Essayez de modifier vos filtres ou votre recherche.</p>
                  <Button onClick={clearFilters}>
                    Effacer les filtres
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
                  {filteredBooks.map((book) => (
                    <BookCard key={book.id} book={book} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
