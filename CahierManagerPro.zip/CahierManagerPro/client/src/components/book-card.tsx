import { Book } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { StarRating } from "@/components/ui/star-rating";
import { useState } from "react";
import { Heart, ShoppingCart } from "lucide-react";
import { useCart } from "@/hooks/use-cart";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface BookCardProps {
  book: Book;
  className?: string;
}

export function BookCard({ book, className }: BookCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);
  const { addToCart } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(book.id, 1);
  };

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsFavorite(!isFavorite);
  };

  return (
    <Link href={`/books/${book.id}`}>
      <Card className={cn(
        "book-card overflow-hidden transition duration-300 hover:-translate-y-1 hover:shadow-lg cursor-pointer",
        className
      )}>
        <div className="relative pb-[140%]">
          <img
            src={book.imageUrl || "https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=420&q=80"}
            alt={`Couverture de ${book.title}`}
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent">
            <div className="text-white text-sm font-medium">{book.author}</div>
          </div>
          {book.discount && (
            <div className="absolute top-0 left-0 bg-secondary text-white text-xs font-bold uppercase py-1 px-3">
              -{book.discount}%
            </div>
          )}
          <button
            className="absolute top-2 right-2 bg-white rounded-full p-1 shadow hover:bg-neutral-100 transition"
            onClick={handleToggleFavorite}
          >
            <Heart 
              className={cn(
                "text-lg", 
                isFavorite ? "text-secondary fill-secondary" : "text-neutral-500"
              )} 
            />
          </button>
        </div>
        <div className="p-3">
          <h3 className="font-medium mb-1 line-clamp-2 h-12">{book.title}</h3>
          <StarRating 
            rating={book.rating} 
            reviews={book.numReviews} 
            className="mb-2" 
          />
          <div className="flex justify-between items-center">
            <div>
              <span className="text-primary-dark font-bold">{book.price.toFixed(2)} €</span>
              {book.oldPrice && (
                <span className="text-neutral-500 text-sm line-through ml-1">
                  {book.oldPrice.toFixed(2)} €
                </span>
              )}
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="text-secondary hover:text-secondary-dark hover:bg-secondary/10"
              onClick={handleAddToCart}
            >
              <ShoppingCart size={20} />
            </Button>
          </div>
        </div>
      </Card>
    </Link>
  );
}
