import { Book } from "@shared/schema";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { StarRating } from "@/components/ui/star-rating";
import { useCart } from "@/hooks/use-cart";
import { cn } from "@/lib/utils";

interface BestsellerCardProps {
  book: Book;
  rank: number;
  className?: string;
}

export function BestsellerCard({ book, rank, className }: BestsellerCardProps) {
  const { addToCart } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(book.id, 1);
  };

  return (
    <Link href={`/books/${book.id}`}>
      <div className={cn(
        "bg-white rounded-lg shadow overflow-hidden cursor-pointer hover:shadow-md transition duration-200",
        className
      )}>
        <div className="flex flex-col md:flex-row">
          <div className="md:w-1/3 relative">
            <div className="absolute top-0 left-0 bg-primary text-white text-xs font-bold uppercase py-1 px-3 z-10">
              TOP {rank}
            </div>
            <img 
              src={book.imageUrl || "https://images.unsplash.com/photo-1541963463532-d68292c34b19?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80"} 
              alt={`${book.title} par ${book.author}`} 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="md:w-2/3 p-4">
            <h3 className="font-medium mb-1">{book.title}</h3>
            <p className="text-neutral-600 text-sm mb-2">{book.author}</p>
            <StarRating 
              rating={book.rating} 
              reviews={book.numReviews} 
              className="mb-2" 
            />
            <p className="text-neutral-600 text-sm line-clamp-2 mb-4">
              {book.description}
            </p>
            <div className="flex justify-between items-center">
              <div className="text-primary-dark font-bold">{book.price.toFixed(2)} €</div>
              <Button
                variant="secondary"
                size="sm"
                className="text-white"
                onClick={handleAddToCart}
              >
                Ajouter au panier
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
