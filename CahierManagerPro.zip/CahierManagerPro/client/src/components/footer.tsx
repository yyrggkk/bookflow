import { Facebook, Twitter, Instagram, Send } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-neutral-800 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center mb-4">
              <span className="text-secondary text-3xl mr-2">📚</span>
              <h2 className="text-xl font-serif font-bold text-white">
                Bibliothèque<span className="text-secondary">Plus</span>
              </h2>
            </div>
            <p className="text-neutral-400 mb-4">
              La marketplace française dédiée aux livres neufs et d'occasion.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-400 hover:text-white">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">Catégories</h3>
            <ul className="space-y-2">
              <li><Link href="/catalog?category=1" className="text-neutral-400 hover:text-white">Romans</Link></li>
              <li><Link href="/catalog?category=2" className="text-neutral-400 hover:text-white">Sciences Humaines</Link></li>
              <li><Link href="/catalog?category=3" className="text-neutral-400 hover:text-white">Science-Fiction</Link></li>
              <li><Link href="/catalog?category=4" className="text-neutral-400 hover:text-white">Jeunesse</Link></li>
              <li><Link href="/catalog?category=5" className="text-neutral-400 hover:text-white">Histoire</Link></li>
              <li><Link href="/catalog" className="text-neutral-400 hover:text-white">Toutes les catégories</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">Informations</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-neutral-400 hover:text-white">Comment ça marche</Link></li>
              <li><Link href="/about" className="text-neutral-400 hover:text-white">À propos de nous</Link></li>
              <li><Link href="/auth?seller=true" className="text-neutral-400 hover:text-white">Devenir vendeur</Link></li>
              <li><a href="#" className="text-neutral-400 hover:text-white">Conditions d'utilisation</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white">Politique de confidentialité</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white">Nous contacter</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">Newsletter</h3>
            <p className="text-neutral-400 mb-4">
              Inscrivez-vous à notre newsletter pour recevoir nos recommandations de lecture.
            </p>
            <form onSubmit={(e) => e.preventDefault()}>
              <div className="flex mb-2">
                <Input
                  type="email"
                  placeholder="Votre email"
                  className="bg-neutral-700 border-neutral-600 text-white rounded-r-none focus:ring-secondary"
                />
                <Button
                  type="submit"
                  variant="default"
                  className="bg-secondary hover:bg-secondary-light rounded-l-none"
                >
                  <Send size={16} />
                </Button>
              </div>
              <div className="flex items-start space-x-2">
                <Checkbox id="newsletter" />
                <Label htmlFor="newsletter" className="text-neutral-400 text-sm font-normal">
                  J'accepte de recevoir des informations commerciales de la part de BibliothèquePlus.
                </Label>
              </div>
            </form>
          </div>
        </div>

        <Separator className="bg-neutral-700" />

        <div className="pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-neutral-400 text-sm mb-4 md:mb-0">
            © 2023 BibliothèquePlus. Tous droits réservés.
          </p>
          <div className="flex items-center space-x-4">
            <a href="#" className="text-neutral-400 hover:text-white text-sm">Mentions légales</a>
            <a href="#" className="text-neutral-400 hover:text-white text-sm">CGV</a>
            <a href="#" className="text-neutral-400 hover:text-white text-sm">Cookies</a>
            <div className="flex items-center">
              <span className="text-neutral-400 mr-2 text-sm">Langue:</span>
              <select className="bg-neutral-700 text-white text-sm p-1 rounded border border-neutral-600">
                <option value="fr" selected>Français</option>
                <option value="en">English</option>
                <option value="es">Español</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
