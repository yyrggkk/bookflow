import { Category } from "@shared/schema";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { 
  BookOpen, 
  Brain, 
  FlaskConical, 
  Baby, 
  Scroll, 
  Library 
} from "lucide-react";

interface CategoryCardProps {
  category: Category;
  className?: string;
}

export function CategoryCard({ category, className }: CategoryCardProps) {
  // Map category icons to Lucide icons
  const iconMap: Record<string, React.ReactNode> = {
    auto_stories: <BookOpen className="text-3xl text-primary" />,
    psychology: <Brain className="text-3xl text-primary" />,
    science: <FlaskConical className="text-3xl text-primary" />,
    child_care: <Baby className="text-3xl text-primary" />,
    history_edu: <Scroll className="text-3xl text-primary" />,
    menu_book: <Library className="text-3xl text-primary" />
  };

  return (
    <Link href={`/catalog?category=${category.id}`}>
      <div className={cn(
        "bg-white rounded-lg shadow p-4 text-center hover:shadow-md transition duration-200 cursor-pointer",
        className
      )}>
        <div className="mb-2">
          {iconMap[category.icon] || <Library className="text-3xl text-primary" />}
        </div>
        <h3 className="font-medium">{category.name}</h3>
      </div>
    </Link>
  );
}
