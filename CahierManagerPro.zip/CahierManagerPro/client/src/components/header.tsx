import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { 
  Search, 
  ShoppingCart, 
  User, 
  ChevronDown 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useMobile } from "@/hooks/use-mobile";
import { cn } from "@/lib/utils";

export function Header() {
  const [location, setLocation] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { cartItems } = useCart();
  const { isMobile } = useMobile();
  const [searchTerm, setSearchTerm] = useState("");
  const [isScrolled, setIsScrolled] = useState(false);
  const cartItemCount = cartItems.length;

  const totalItems = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      setLocation(`/catalog?search=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      if (scrollPosition > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className={cn(
      "bg-white sticky top-0 z-50 transition-shadow duration-300",
      isScrolled ? "shadow-md" : "shadow"
    )}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <span className="text-primary text-3xl mr-2">📚</span>
              <h1 className="text-xl md:text-2xl font-serif font-bold text-primary">
                Bibliothèque<span className="text-secondary">Plus</span>
              </h1>
            </Link>
          </div>

          <div className="hidden md:block flex-grow max-w-xl mx-8">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Rechercher par titre, auteur, catégorie..."
                className="w-full py-2 px-4 border border-neutral-300 rounded-full focus:ring-2 focus:ring-primary focus:border-transparent"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Button
                type="submit"
                variant="ghost"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-neutral-500 hover:text-primary hover:bg-transparent p-1"
              >
                <Search size={20} />
              </Button>
            </form>
          </div>

          <div className="flex items-center space-x-2 md:space-x-6">
            <Link href="/cart" className="flex items-center text-neutral-700 hover:text-primary">
              <Button variant="ghost" className="p-2">
                <ShoppingCart size={isMobile ? 24 : 20} />
                <span className="ml-1 hidden md:inline">Panier</span>
                {totalItems > 0 && (
                  <span className="bg-secondary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center ml-1">
                    {totalItems}
                  </span>
                )}
              </Button>
            </Link>

            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center text-neutral-700 hover:text-primary">
                    <User size={isMobile ? 24 : 20} />
                    <span className="ml-1 hidden md:inline">{user.username}</span>
                    <ChevronDown size={16} className="ml-1" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem asChild>
                    <Link href="/profile">Mon profil</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/orders">Mes commandes</Link>
                  </DropdownMenuItem>
                  {user.role === 'seller' && (
                    <DropdownMenuItem asChild>
                      <Link href="/seller-dashboard">Tableau de bord vendeur</Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    Déconnexion
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button asChild className="bg-primary text-white hover:bg-primary-dark transition duration-200">
                <Link href="/auth">Connexion</Link>
              </Button>
            )}
          </div>
        </div>

        <div className="md:hidden py-3">
          {/* Mobile search */}
          <form onSubmit={handleSearch} className="relative">
            <Input
              type="text"
              placeholder="Rechercher..."
              className="w-full py-2 px-4 border border-neutral-300 rounded-full focus:ring-2 focus:ring-primary focus:border-transparent"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Button
              type="submit"
              variant="ghost"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-neutral-500 hover:text-primary hover:bg-transparent p-1"
            >
              <Search size={20} />
            </Button>
          </form>
        </div>

        <nav className="flex overflow-x-auto py-3 -mx-4 px-4 scrollbar-hide">
          <div className="flex space-x-6 font-medium text-neutral-600">
            <Link href="/" className={cn(
              "whitespace-nowrap hover:text-primary pb-2 border-b-2 transition-colors",
              location === "/" ? "border-primary text-primary" : "border-transparent"
            )}>
              Accueil
            </Link>
            <Link href="/catalog?featured=true" className={cn(
              "whitespace-nowrap hover:text-primary pb-2 border-b-2 transition-colors",
              location === "/catalog?featured=true" ? "border-primary text-primary" : "border-transparent"
            )}>
              Nouveautés
            </Link>
            <Link href="/catalog?bestseller=true" className={cn(
              "whitespace-nowrap hover:text-primary pb-2 border-b-2 transition-colors",
              location === "/catalog?bestseller=true" ? "border-primary text-primary" : "border-transparent"
            )}>
              Meilleures ventes
            </Link>
            <Link href="/catalog?category=1" className={cn(
              "whitespace-nowrap hover:text-primary pb-2 border-b-2 transition-colors",
              location === "/catalog?category=1" ? "border-primary text-primary" : "border-transparent"
            )}>
              Romans
            </Link>
            <Link href="/catalog?category=3" className={cn(
              "whitespace-nowrap hover:text-primary pb-2 border-b-2 transition-colors",
              location === "/catalog?category=3" ? "border-primary text-primary" : "border-transparent"
            )}>
              Science-Fiction
            </Link>
            <Link href="/catalog?category=5" className={cn(
              "whitespace-nowrap hover:text-primary pb-2 border-b-2 transition-colors",
              location === "/catalog?category=5" ? "border-primary text-primary" : "border-transparent"
            )}>
              Histoire
            </Link>
            <Link href="/catalog?category=4" className={cn(
              "whitespace-nowrap hover:text-primary pb-2 border-b-2 transition-colors",
              location === "/catalog?category=4" ? "border-primary text-primary" : "border-transparent"
            )}>
              Jeunesse
            </Link>
            <Link href="/catalog" className={cn(
              "whitespace-nowrap hover:text-primary pb-2 border-b-2 transition-colors",
              location === "/catalog" ? "border-primary text-primary" : "border-transparent"
            )}>
              Toutes les catégories
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
}
