import * as React from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User } from "lucide-react";

interface AvatarFlagProps {
  src?: string;
  fallback?: string;
  flag?: React.ReactNode;
  alt?: string;
  onClick?: () => void;
  className?: string;
}

export function AvatarFlag({
  src,
  fallback,
  flag,
  alt,
  onClick,
  className,
}: AvatarFlagProps) {
  const defaultFallback = fallback || <User className="h-5 w-5" />;
  
  return (
    <div className={`relative inline-block ${className}`} onClick={onClick}>
      <Avatar className="cursor-pointer">
        <AvatarImage src={src} alt={alt || "Avatar"} />
        <AvatarFallback>{defaultFallback}</AvatarFallback>
      </Avatar>
      {flag && (
        <div className="absolute -bottom-1 -right-1">
          {flag}
        </div>
      )}
    </div>
  );
}
