import { useState } from "react";
import { Star, StarHalf } from "lucide-react";
import { cn } from "@/lib/utils";

interface StarRatingProps {
  rating: number;
  maxRating?: number;
  reviews?: number;
  size?: "xs" | "sm" | "md";
  showReviews?: boolean;
  className?: string;
  interactive?: boolean;
  onRatingChange?: (rating: number) => void;
}

export function StarRating({
  rating,
  maxRating = 5,
  reviews,
  size = "sm",
  showReviews = true,
  className = "",
  interactive = false,
  onRatingChange
}: StarRatingProps) {
  const [hoverRating, setHoverRating] = useState(0);
  
  const sizeClasses = {
    xs: "h-3 w-3",
    sm: "h-4 w-4",
    md: "h-5 w-5"
  };
  
  const handleClick = (index: number) => {
    if (interactive && onRatingChange) {
      onRatingChange(index);
    }
  };

  const renderStar = (index: number) => {
    const starValue = index + 1;
    let filled = false;
    let half = false;
    
    if (interactive && hoverRating > 0) {
      filled = hoverRating >= starValue;
    } else {
      filled = rating >= starValue;
      half = !filled && rating > starValue - 1;
    }
    
    return (
      <div 
        key={index}
        className={interactive ? "cursor-pointer" : ""}
        onClick={() => handleClick(starValue)}
        onMouseEnter={() => interactive && setHoverRating(starValue)}
        onMouseLeave={() => interactive && setHoverRating(0)}
      >
        {half ? (
          <StarHalf 
            className={cn(sizeClasses[size], "text-amber-400")} 
            fill="currentColor" 
          />
        ) : (
          <Star 
            className={cn(
              sizeClasses[size], 
              filled ? "text-amber-400" : "text-gray-300"
            )} 
            fill={filled ? "currentColor" : "none"} 
          />
        )}
      </div>
    );
  };

  return (
    <div className={cn("flex items-center", className)}>
      <div className="flex">
        {[...Array(maxRating)].map((_, i) => renderStar(i))}
      </div>
      {showReviews && reviews !== undefined && (
        <span className={cn(
          "ml-1 text-gray-600",
          size === "xs" ? "text-xs" : "",
          size === "sm" ? "text-sm" : "",
          size === "md" ? "text-base" : ""
        )}>
          ({reviews})
        </span>
      )}
    </div>
  );
}
