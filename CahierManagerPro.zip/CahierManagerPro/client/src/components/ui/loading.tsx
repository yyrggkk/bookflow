import { Loader2 } from "lucide-react";

export function LoadingSpinner({ size = "default", className = "" }: { size?: "small" | "default" | "large", className?: string }) {
  const sizeClass = {
    small: "h-4 w-4",
    default: "h-8 w-8",
    large: "h-12 w-12"
  }[size];

  return (
    <Loader2 className={`animate-spin text-primary ${sizeClass} ${className}`} />
  );
}

export function LoadingPage() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <LoadingSpinner size="large" />
    </div>
  );
}

export function LoadingSection() {
  return (
    <div className="flex items-center justify-center py-12">
      <LoadingSpinner />
    </div>
  );
}
