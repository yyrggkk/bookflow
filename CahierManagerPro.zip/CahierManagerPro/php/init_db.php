<?php
/**
 * Script d'initialisation de la base de données
 * BibliothèquePlus
 */

// Inclure le fichier de configuration
require_once 'config.php';

// Connexion à la base de données MySQL sans sélectionner de base de données
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";charset=" . DB_CHARSET, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Créer la base de données si elle n'existe pas
    $stmt = $pdo->prepare("CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET " . DB_CHARSET . " COLLATE " . DB_CHARSET . "_unicode_ci");
    $stmt->execute();
    
    echo "Base de données créée ou déjà existante.<br>";
    
    // Sélectionner la base de données
    $pdo->exec("USE " . DB_NAME);
    
    // Création des tables
    $tables = [
        // Table des utilisateurs
        "CREATE TABLE IF NOT EXISTS users (
            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            full_name VARCHAR(100) DEFAULT NULL,
            address TEXT DEFAULT NULL,
            phone VARCHAR(20) DEFAULT NULL,
            role ENUM('buyer', 'seller') NOT NULL DEFAULT 'buyer',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=" . DB_CHARSET,
        
        // Table des catégories
        "CREATE TABLE IF NOT EXISTS categories (
            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            icon VARCHAR(50) DEFAULT NULL,
            image_url VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=" . DB_CHARSET,
        
        // Table des livres
        "CREATE TABLE IF NOT EXISTS books (
            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            author VARCHAR(100) NOT NULL,
            description TEXT,
            price DECIMAL(10,2) NOT NULL,
            old_price DECIMAL(10,2) DEFAULT NULL,
            image_url VARCHAR(255) DEFAULT NULL,
            category_id INT(11) UNSIGNED NOT NULL,
            seller_id INT(11) UNSIGNED NOT NULL,
            stock INT(11) NOT NULL DEFAULT 1,
            featured BOOLEAN NOT NULL DEFAULT FALSE,
            best_seller BOOLEAN NOT NULL DEFAULT FALSE,
            discount INT(3) UNSIGNED DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
            FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=" . DB_CHARSET,
        
        // Table des éléments du panier
        "CREATE TABLE IF NOT EXISTS cart_items (
            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT(11) UNSIGNED NOT NULL,
            book_id INT(11) UNSIGNED NOT NULL,
            quantity INT(11) NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=" . DB_CHARSET,
        
        // Table des commandes
        "CREATE TABLE IF NOT EXISTS orders (
            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT(11) UNSIGNED NOT NULL,
            total_amount DECIMAL(10,2) NOT NULL,
            status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') NOT NULL DEFAULT 'pending',
            shipping_address TEXT NOT NULL,
            payment_method VARCHAR(50) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=" . DB_CHARSET,
        
        // Table des éléments de commande
        "CREATE TABLE IF NOT EXISTS order_items (
            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            order_id INT(11) UNSIGNED NOT NULL,
            book_id INT(11) UNSIGNED NOT NULL,
            quantity INT(11) NOT NULL DEFAULT 1,
            price DECIMAL(10,2) NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=" . DB_CHARSET,
        
        // Table des avis/commentaires
        "CREATE TABLE IF NOT EXISTS reviews (
            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            book_id INT(11) UNSIGNED NOT NULL,
            user_id INT(11) UNSIGNED NOT NULL,
            rating TINYINT(1) NOT NULL,
            comment TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=" . DB_CHARSET
    ];
    
    // Exécuter les requêtes de création de tables
    foreach ($tables as $table) {
        $pdo->exec($table);
    }
    
    echo "Tables créées avec succès.<br>";
    
    // Insérer des données d'exemple si les tables sont vides
    
    // Vérifier si la table users est vide
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $userCount = $stmt->fetchColumn();
    
    if ($userCount == 0) {
        // Insérer des utilisateurs de démonstration
        $users = [
            [
                'username' => 'admin',
                'password' => password_hash('admin123', PASSWORD_DEFAULT),
                'email' => 'admin@bibliothequeplus.fr',
                'full_name' => 'Administrateur',
                'role' => 'seller'
            ],
            [
                'username' => 'jean',
                'password' => password_hash('jean123', PASSWORD_DEFAULT),
                'email' => 'jean@example.com',
                'full_name' => 'Jean Dupont',
                'role' => 'buyer'
            ],
            [
                'username' => 'marie',
                'password' => password_hash('marie123', PASSWORD_DEFAULT),
                'email' => 'marie@example.com',
                'full_name' => 'Marie Durand',
                'role' => 'seller'
            ]
        ];
        
        $stmt = $pdo->prepare("INSERT INTO users (username, password, email, full_name, role) VALUES (:username, :password, :email, :full_name, :role)");
        
        foreach ($users as $user) {
            $stmt->execute($user);
        }
        
        echo "Utilisateurs de démonstration créés.<br>";
    }
    
    // Vérifier si la table categories est vide
    $stmt = $pdo->query("SELECT COUNT(*) FROM categories");
    $categoryCount = $stmt->fetchColumn();
    
    if ($categoryCount == 0) {
        // Insérer des catégories de démonstration
        $categories = [
            [
                'name' => 'Romans',
                'icon' => 'book',
                'image_url' => 'https://images.unsplash.com/photo-1512820790803-83ca734da794'
            ],
            [
                'name' => 'Histoire',
                'icon' => 'landmark',
                'image_url' => 'https://images.unsplash.com/photo-1461360228754-6e81c478b882'
            ],
            [
                'name' => 'Philosophie',
                'icon' => 'brain',
                'image_url' => 'https://images.unsplash.com/photo-1544396821-4dd40b938ad3'
            ],
            [
                'name' => 'Science Fiction',
                'icon' => 'rocket',
                'image_url' => 'https://images.unsplash.com/photo-1532012197267-da84d127e765'
            ],
            [
                'name' => 'Développement Personnel',
                'icon' => 'user',
                'image_url' => 'https://images.unsplash.com/photo-1571425046056-2d0321b9cd8b'
            ]
        ];
        
        $stmt = $pdo->prepare("INSERT INTO categories (name, icon, image_url) VALUES (:name, :icon, :image_url)");
        
        foreach ($categories as $category) {
            $stmt->execute($category);
        }
        
        echo "Catégories de démonstration créées.<br>";
    }
    
    // Vérifier si la table books est vide
    $stmt = $pdo->query("SELECT COUNT(*) FROM books");
    $bookCount = $stmt->fetchColumn();
    
    if ($bookCount == 0) {
        // Obtenir l'ID du vendeur (admin)
        $stmt = $pdo->query("SELECT id FROM users WHERE username = 'admin'");
        $adminId = $stmt->fetchColumn();
        
        // Obtenir l'ID du vendeur (marie)
        $stmt = $pdo->query("SELECT id FROM users WHERE username = 'marie'");
        $marieId = $stmt->fetchColumn();
        
        // Insérer des livres de démonstration
        $books = [
            [
                'title' => 'L\'Art de la Guerre',
                'author' => 'Sun Tzu',
                'description' => 'Un classique de la stratégie militaire qui a inspiré de nombreux leaders à travers l\'histoire.',
                'price' => 14.99,
                'old_price' => null,
                'image_url' => 'https://images.unsplash.com/photo-1544947950-fa07a98d237f',
                'category_id' => 3, // Philosophie
                'seller_id' => $adminId,
                'stock' => 10,
                'featured' => true,
                'best_seller' => true
            ],
            [
                'title' => 'Le Petit Prince',
                'author' => 'Antoine de Saint-Exupéry',
                'description' => 'Une histoire poétique qui aborde les thèmes de l\'amour, l\'amitié et le sens de la vie.',
                'price' => 12.50,
                'old_price' => 15.99,
                'image_url' => 'https://images.unsplash.com/photo-1629992101753-56d196c8aabb',
                'category_id' => 1, // Romans
                'seller_id' => $marieId,
                'stock' => 15,
                'featured' => true,
                'best_seller' => true
            ],
            [
                'title' => 'Sapiens: Une brève histoire de l\'humanité',
                'author' => 'Yuval Noah Harari',
                'description' => 'Une exploration de l\'histoire humaine et de comment nous en sommes arrivés là.',
                'price' => 22.90,
                'old_price' => null,
                'image_url' => 'https://images.unsplash.com/photo-1491841550275-ad7854e35ca6',
                'category_id' => 2, // Histoire
                'seller_id' => $adminId,
                'stock' => 8,
                'featured' => true,
                'best_seller' => false
            ],
            [
                'title' => 'Harry Potter à l\'école des sorciers',
                'author' => 'J.K. Rowling',
                'description' => 'Le premier tome de la célèbre série qui a captivé des millions de lecteurs dans le monde.',
                'price' => 19.99,
                'old_price' => 24.99,
                'image_url' => 'https://images.unsplash.com/photo-1551269901-5c5e14c25df7',
                'category_id' => 4, // Science Fiction
                'seller_id' => $marieId,
                'stock' => 20,
                'featured' => true,
                'best_seller' => true
            ],
            [
                'title' => 'Les Misérables',
                'author' => 'Victor Hugo',
                'description' => 'Un chef-d\'œuvre de la littérature française qui explore la justice, la politique et l\'amour.',
                'price' => 17.50,
                'old_price' => null,
                'image_url' => 'https://images.unsplash.com/photo-1629992101753-56d196c8aabb',
                'category_id' => 1, // Romans
                'seller_id' => $adminId,
                'stock' => 5,
                'featured' => false,
                'best_seller' => true
            ],
            [
                'title' => 'L\'Alchimiste',
                'author' => 'Paulo Coelho',
                'description' => 'Une fable qui inspire à suivre ses rêves et à trouver sa légende personnelle.',
                'price' => 11.90,
                'old_price' => 14.90,
                'image_url' => 'https://images.unsplash.com/photo-1544947950-fa07a98d237f',
                'category_id' => 5, // Développement Personnel
                'seller_id' => $marieId,
                'stock' => 12,
                'featured' => false,
                'best_seller' => true
            ]
        ];
        
        $stmt = $pdo->prepare("INSERT INTO books (title, author, description, price, old_price, image_url, category_id, seller_id, stock, featured, best_seller) VALUES (:title, :author, :description, :price, :old_price, :image_url, :category_id, :seller_id, :stock, :featured, :best_seller)");
        
        foreach ($books as $book) {
            $stmt->execute($book);
        }
        
        echo "Livres de démonstration créés.<br>";
    }
    
    echo "Initialisation de la base de données terminée avec succès !";
    
} catch (PDOException $e) {
    die("Erreur lors de l'initialisation de la base de données : " . $e->getMessage());
}