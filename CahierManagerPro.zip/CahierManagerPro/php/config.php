<?php
/**
 * Configuration de la base de données et variables globales
 * BibliothèquePlus
 */

// Mode développement (true) ou production (false)
define('DEV_MODE', true);

// Configuration de la base de données
define('DB_HOST', 'localhost');
define('DB_NAME', 'bibliothequeplus');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// URL de base du site
define('BASE_URL', 'http://localhost');

// Clé secrète pour les sessions et les tokens
define('SECRET_KEY', 'bibliothequeplus_secret_key_change_in_production');

// Durée de validité des sessions (en secondes)
define('SESSION_LIFETIME', 60 * 60 * 24 * 7); // 7 jours

// Paramètres de téléchargement des images
define('UPLOAD_DIR', '../uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5 Mo
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif']);

// Paramètres de pagination
define('ITEMS_PER_PAGE', 12);

// Options pour les livraisons
define('FREE_SHIPPING_THRESHOLD', 35); // Livraison gratuite à partir de 35€
define('SHIPPING_COST', 3.99); // Frais de livraison par défaut

// Configuration des emails
define('SMTP_HOST', 'smtp.example.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'contact@bibliothequeplus.fr');
define('SMTP_PASSWORD', '');
define('MAIL_FROM', 'contact@bibliothequeplus.fr');
define('MAIL_FROM_NAME', 'BibliothèquePlus');

/**
 * Fonction pour afficher les erreurs (uniquement en mode développement)
 */
if (DEV_MODE) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

/**
 * Fonction de connexion à la base de données
 * @return PDO Instance de connexion PDO
 */
function connectDB() {
    try {
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        if (DEV_MODE) {
            die('Erreur de connexion à la base de données: ' . $e->getMessage());
        } else {
            die('Erreur de connexion à la base de données. Veuillez réessayer plus tard.');
        }
    }
}

/**
 * Fonction d'échappement des données pour éviter les injections XSS
 * @param string $data Données à échapper
 * @return string Données échappées
 */
function escape($data) {
    if (is_array($data)) {
        foreach ($data as $key => $value) {
            $data[$key] = escape($value);
        }
        return $data;
    }
    
    if (is_string($data)) {
        return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    }
    
    return $data;
}

/**
 * Fonction pour générer une réponse JSON
 * @param mixed $data Données à renvoyer
 * @param int $status Code de statut HTTP
 */
function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Fonction pour vérifier si l'utilisateur est connecté
 * @return bool True si l'utilisateur est connecté, sinon False
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Fonction pour obtenir l'ID de l'utilisateur connecté
 * @return int|null ID de l'utilisateur ou null si non connecté
 */
function getCurrentUserId() {
    return isLoggedIn() ? $_SESSION['user_id'] : null;
}

/**
 * Fonction pour vérifier si l'utilisateur a le rôle de vendeur
 * @return bool True si l'utilisateur est un vendeur, sinon False
 */
function isSeller() {
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'seller';
}

/**
 * Démarrage de la session
 */
session_start();