<?php
/**
 * API des livres
 * BibliothèquePlus
 */

// Inclure le fichier de configuration
require_once '../config.php';

// Entêtes pour CORS et JSON
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Connexion à la base de données
$pdo = connectDB();

// Obtenir la méthode HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Récupérer l'ID du livre à partir de l'URL
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

// Traiter la requête en fonction de la méthode HTTP
switch ($method) {
    case 'GET':
        if ($id) {
            // Récupérer un livre spécifique
            getBook($pdo, $id);
        } else {
            // Récupérer la liste des livres avec filtres
            getBooks($pdo);
        }
        break;
        
    case 'POST':
        // Vérifier si l'utilisateur est connecté et est un vendeur
        if (!isLoggedIn() || !isSeller()) {
            jsonResponse(['error' => 'Accès refusé'], 403);
        }
        
        // Créer un nouveau livre
        createBook($pdo);
        break;
        
    case 'PUT':
        // Vérifier si l'utilisateur est connecté et est un vendeur
        if (!isLoggedIn() || !isSeller() || !$id) {
            jsonResponse(['error' => 'Accès refusé'], 403);
        }
        
        // Mettre à jour un livre existant
        updateBook($pdo, $id);
        break;
        
    case 'DELETE':
        // Vérifier si l'utilisateur est connecté et est un vendeur
        if (!isLoggedIn() || !isSeller() || !$id) {
            jsonResponse(['error' => 'Accès refusé'], 403);
        }
        
        // Supprimer un livre
        deleteBook($pdo, $id);
        break;
        
    default:
        // Méthode non autorisée
        jsonResponse(['error' => 'Méthode non autorisée'], 405);
        break;
}

/**
 * Récupérer tous les livres avec filtres optionnels
 * @param PDO $pdo Instance de connexion PDO
 */
function getBooks($pdo) {
    try {
        $sql = "SELECT b.*, c.name as category_name 
                FROM books b 
                JOIN categories c ON b.category_id = c.id 
                WHERE 1=1";
        $params = [];
        
        // Filtrer par livres mis en avant
        if (isset($_GET['featured']) && $_GET['featured'] === 'true') {
            $sql .= " AND b.featured = 1";
        }
        
        // Filtrer par meilleures ventes
        if (isset($_GET['bestseller']) && $_GET['bestseller'] === 'true') {
            $sql .= " AND b.best_seller = 1";
        }
        
        // Filtrer par catégorie
        if (isset($_GET['category']) && intval($_GET['category']) > 0) {
            $sql .= " AND b.category_id = :category_id";
            $params[':category_id'] = intval($_GET['category']);
        }
        
        // Filtrer par vendeur
        if (isset($_GET['seller']) && intval($_GET['seller']) > 0) {
            $sql .= " AND b.seller_id = :seller_id";
            $params[':seller_id'] = intval($_GET['seller']);
        }
        
        // Recherche par titre ou auteur
        if (isset($_GET['search']) && !empty($_GET['search'])) {
            $sql .= " AND (b.title LIKE :search OR b.author LIKE :search)";
            $params[':search'] = '%' . $_GET['search'] . '%';
        }
        
        // Limiter le nombre de résultats
        if (isset($_GET['limit']) && intval($_GET['limit']) > 0) {
            $sql .= " LIMIT :limit";
            $params[':limit'] = intval($_GET['limit']);
        }
        
        // Préparer et exécuter la requête
        $stmt = $pdo->prepare($sql);
        
        // Lier les paramètres
        foreach ($params as $key => $value) {
            if ($key === ':limit') {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Pour chaque livre, récupérer sa note moyenne
        foreach ($books as &$book) {
            $book['rating'] = getBookRating($pdo, $book['id']);
        }
        
        jsonResponse($books);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Erreur lors de la récupération des livres: ' . $e->getMessage()], 500);
    }
}

/**
 * Récupérer un livre spécifique
 * @param PDO $pdo Instance de connexion PDO
 * @param int $id ID du livre
 */
function getBook($pdo, $id) {
    try {
        $sql = "SELECT b.*, c.name as category_name, u.username as seller_username 
                FROM books b 
                JOIN categories c ON b.category_id = c.id 
                JOIN users u ON b.seller_id = u.id 
                WHERE b.id = :id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $book = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$book) {
            jsonResponse(['error' => 'Livre non trouvé'], 404);
        }
        
        // Récupérer la note moyenne du livre
        $book['rating'] = getBookRating($pdo, $id);
        
        // Récupérer les avis du livre
        $stmt = $pdo->prepare("SELECT r.*, u.username 
                             FROM reviews r 
                             JOIN users u ON r.user_id = u.id 
                             WHERE r.book_id = :book_id 
                             ORDER BY r.created_at DESC");
        $stmt->bindValue(':book_id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $book['reviews'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse($book);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Erreur lors de la récupération du livre: ' . $e->getMessage()], 500);
    }
}

/**
 * Créer un nouveau livre
 * @param PDO $pdo Instance de connexion PDO
 */
function createBook($pdo) {
    try {
        // Récupérer et décoder les données JSON du corps de la requête
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (!$data) {
            jsonResponse(['error' => 'Données invalides'], 400);
        }
        
        // Valider les données requises
        if (empty($data['title']) || empty($data['author']) || !isset($data['price']) || empty($data['category_id'])) {
            jsonResponse(['error' => 'Données incomplètes'], 400);
        }
        
        // Préparer la requête d'insertion
        $sql = "INSERT INTO books (title, author, description, price, old_price, image_url, category_id, seller_id, stock, featured, best_seller, discount) 
                VALUES (:title, :author, :description, :price, :old_price, :image_url, :category_id, :seller_id, :stock, :featured, :best_seller, :discount)";
        
        $stmt = $pdo->prepare($sql);
        
        // Lier les paramètres
        $stmt->bindValue(':title', $data['title']);
        $stmt->bindValue(':author', $data['author']);
        $stmt->bindValue(':description', $data['description'] ?? null);
        $stmt->bindValue(':price', $data['price']);
        $stmt->bindValue(':old_price', $data['old_price'] ?? null);
        $stmt->bindValue(':image_url', $data['image_url'] ?? null);
        $stmt->bindValue(':category_id', $data['category_id'], PDO::PARAM_INT);
        $stmt->bindValue(':seller_id', getCurrentUserId(), PDO::PARAM_INT);
        $stmt->bindValue(':stock', $data['stock'] ?? 1, PDO::PARAM_INT);
        $stmt->bindValue(':featured', $data['featured'] ?? false, PDO::PARAM_BOOL);
        $stmt->bindValue(':best_seller', $data['best_seller'] ?? false, PDO::PARAM_BOOL);
        $stmt->bindValue(':discount', $data['discount'] ?? null);
        
        $stmt->execute();
        
        // Récupérer l'ID du livre inséré
        $bookId = $pdo->lastInsertId();
        
        // Récupérer le livre nouvellement créé
        $stmt = $pdo->prepare("SELECT * FROM books WHERE id = :id");
        $stmt->bindValue(':id', $bookId, PDO::PARAM_INT);
        $stmt->execute();
        
        $book = $stmt->fetch(PDO::FETCH_ASSOC);
        
        jsonResponse($book, 201);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Erreur lors de la création du livre: ' . $e->getMessage()], 500);
    }
}

/**
 * Mettre à jour un livre existant
 * @param PDO $pdo Instance de connexion PDO
 * @param int $id ID du livre à mettre à jour
 */
function updateBook($pdo, $id) {
    try {
        // Vérifier si le livre existe et appartient au vendeur
        $stmt = $pdo->prepare("SELECT * FROM books WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $book = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$book) {
            jsonResponse(['error' => 'Livre non trouvé'], 404);
        }
        
        if ($book['seller_id'] != getCurrentUserId()) {
            jsonResponse(['error' => 'Vous n\'êtes pas autorisé à modifier ce livre'], 403);
        }
        
        // Récupérer et décoder les données JSON du corps de la requête
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (!$data) {
            jsonResponse(['error' => 'Données invalides'], 400);
        }
        
        // Préparer la requête de mise à jour
        $sql = "UPDATE books SET 
                title = :title, 
                author = :author, 
                description = :description, 
                price = :price, 
                old_price = :old_price, 
                image_url = :image_url, 
                category_id = :category_id, 
                stock = :stock, 
                featured = :featured, 
                best_seller = :best_seller, 
                discount = :discount 
                WHERE id = :id";
        
        $stmt = $pdo->prepare($sql);
        
        // Lier les paramètres
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->bindValue(':title', $data['title'] ?? $book['title']);
        $stmt->bindValue(':author', $data['author'] ?? $book['author']);
        $stmt->bindValue(':description', $data['description'] ?? $book['description']);
        $stmt->bindValue(':price', $data['price'] ?? $book['price']);
        $stmt->bindValue(':old_price', $data['old_price'] ?? $book['old_price']);
        $stmt->bindValue(':image_url', $data['image_url'] ?? $book['image_url']);
        $stmt->bindValue(':category_id', $data['category_id'] ?? $book['category_id'], PDO::PARAM_INT);
        $stmt->bindValue(':stock', $data['stock'] ?? $book['stock'], PDO::PARAM_INT);
        $stmt->bindValue(':featured', $data['featured'] ?? $book['featured'], PDO::PARAM_BOOL);
        $stmt->bindValue(':best_seller', $data['best_seller'] ?? $book['best_seller'], PDO::PARAM_BOOL);
        $stmt->bindValue(':discount', $data['discount'] ?? $book['discount']);
        
        $stmt->execute();
        
        // Récupérer le livre mis à jour
        $stmt = $pdo->prepare("SELECT * FROM books WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $updatedBook = $stmt->fetch(PDO::FETCH_ASSOC);
        
        jsonResponse($updatedBook);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Erreur lors de la mise à jour du livre: ' . $e->getMessage()], 500);
    }
}

/**
 * Supprimer un livre
 * @param PDO $pdo Instance de connexion PDO
 * @param int $id ID du livre à supprimer
 */
function deleteBook($pdo, $id) {
    try {
        // Vérifier si le livre existe et appartient au vendeur
        $stmt = $pdo->prepare("SELECT * FROM books WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $book = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$book) {
            jsonResponse(['error' => 'Livre non trouvé'], 404);
        }
        
        if ($book['seller_id'] != getCurrentUserId()) {
            jsonResponse(['error' => 'Vous n\'êtes pas autorisé à supprimer ce livre'], 403);
        }
        
        // Supprimer le livre
        $stmt = $pdo->prepare("DELETE FROM books WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        jsonResponse(['message' => 'Livre supprimé avec succès']);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Erreur lors de la suppression du livre: ' . $e->getMessage()], 500);
    }
}

/**
 * Récupérer la note moyenne d'un livre
 * @param PDO $pdo Instance de connexion PDO
 * @param int $bookId ID du livre
 * @return float Note moyenne du livre
 */
function getBookRating($pdo, $bookId) {
    try {
        $stmt = $pdo->prepare("SELECT AVG(rating) as average_rating FROM reviews WHERE book_id = :book_id");
        $stmt->bindValue(':book_id', $bookId, PDO::PARAM_INT);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['average_rating'] ? round(floatval($result['average_rating']), 1) : 0;
    } catch (PDOException $e) {
        return 0;
    }
}