<?php
/**
 * API des catégories
 * BibliothèquePlus
 */

// Inclure le fichier de configuration
require_once '../config.php';

// Entêtes pour CORS et JSON
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Connexion à la base de données
$pdo = connectDB();

// Obtenir la méthode HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Récupérer l'ID de la catégorie à partir de l'URL
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

// Traiter la requête en fonction de la méthode HTTP
switch ($method) {
    case 'GET':
        if ($id) {
            // Récupérer une catégorie spécifique
            getCategory($pdo, $id);
        } else {
            // Récupérer toutes les catégories
            getCategories($pdo);
        }
        break;
        
    default:
        // Méthode non autorisée
        jsonResponse(['error' => 'Méthode non autorisée'], 405);
        break;
}

/**
 * Récupérer toutes les catégories
 * @param PDO $pdo Instance de connexion PDO
 */
function getCategories($pdo) {
    try {
        $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse($categories);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Erreur lors de la récupération des catégories: ' . $e->getMessage()], 500);
    }
}

/**
 * Récupérer une catégorie spécifique
 * @param PDO $pdo Instance de connexion PDO
 * @param int $id ID de la catégorie
 */
function getCategory($pdo, $id) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $category = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$category) {
            jsonResponse(['error' => 'Catégorie non trouvée'], 404);
        }
        
        // Récupérer les livres de cette catégorie
        $stmt = $pdo->prepare("SELECT id, title, author, price, old_price, image_url, featured, best_seller FROM books WHERE category_id = :category_id");
        $stmt->bindValue(':category_id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $category['books'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse($category);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Erreur lors de la récupération de la catégorie: ' . $e->getMessage()], 500);
    }
}