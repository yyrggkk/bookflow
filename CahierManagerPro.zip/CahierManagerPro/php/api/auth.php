<?php
/**
 * API d'authentification
 * BibliothèquePlus
 */

// Inclure le fichier de configuration
require_once '../config.php';

// Entêtes pour CORS et JSON
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Connexion à la base de données
$pdo = connectDB();

// Obtenir la méthode HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Obtenir le chemin de l'URL
$requestUri = $_SERVER['REQUEST_URI'];
$path = parse_url($requestUri, PHP_URL_PATH);
$segments = explode('/', trim($path, '/'));
$endpoint = end($segments);

// Traiter la requête en fonction de la méthode HTTP et de l'endpoint
if ($method === 'POST') {
    switch ($endpoint) {
        case 'login':
            login($pdo);
            break;
            
        case 'register':
            register($pdo);
            break;
            
        case 'logout':
            logout();
            break;
            
        default:
            jsonResponse(['error' => 'Endpoint non trouvé'], 404);
            break;
    }
} elseif ($method === 'GET' && $endpoint === 'user') {
    getCurrentUser();
} else {
    // Méthode non autorisée
    jsonResponse(['error' => 'Méthode non autorisée'], 405);
}

/**
 * Connexion d'un utilisateur
 * @param PDO $pdo Instance de connexion PDO
 */
function login($pdo) {
    try {
        // Récupérer et décoder les données JSON du corps de la requête
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (!$data || empty($data['username']) || empty($data['password'])) {
            jsonResponse(['error' => 'Veuillez fournir un nom d\'utilisateur et un mot de passe'], 400);
        }
        
        // Récupérer l'utilisateur par son nom d'utilisateur
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->bindValue(':username', $data['username']);
        $stmt->execute();
        
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user || !password_verify($data['password'], $user['password'])) {
            jsonResponse(['error' => 'Nom d\'utilisateur ou mot de passe incorrect'], 401);
        }
        
        // Créer une session utilisateur
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['username'] = $user['username'];
        
        // Supprimer le mot de passe de la réponse
        unset($user['password']);
        
        jsonResponse([
            'success' => true,
            'message' => 'Connexion réussie',
            'user' => $user
        ]);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Erreur lors de la connexion: ' . $e->getMessage()], 500);
    }
}

/**
 * Inscription d'un nouvel utilisateur
 * @param PDO $pdo Instance de connexion PDO
 */
function register($pdo) {
    try {
        // Récupérer et décoder les données JSON du corps de la requête
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (!$data || empty($data['username']) || empty($data['email']) || empty($data['password'])) {
            jsonResponse(['error' => 'Veuillez fournir tous les champs requis'], 400);
        }
        
        // Vérifier si le nom d'utilisateur existe déjà
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username");
        $stmt->bindValue(':username', $data['username']);
        $stmt->execute();
        
        if ($stmt->fetch()) {
            jsonResponse(['error' => 'Ce nom d\'utilisateur est déjà utilisé'], 400);
        }
        
        // Vérifier si l'email existe déjà
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email");
        $stmt->bindValue(':email', $data['email']);
        $stmt->execute();
        
        if ($stmt->fetch()) {
            jsonResponse(['error' => 'Cet email est déjà utilisé'], 400);
        }
        
        // Hacher le mot de passe
        $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
        
        // Insérer le nouvel utilisateur
        $sql = "INSERT INTO users (username, password, email, full_name, role) 
                VALUES (:username, :password, :email, :full_name, :role)";
                
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':username', $data['username']);
        $stmt->bindValue(':password', $hashedPassword);
        $stmt->bindValue(':email', $data['email']);
        $stmt->bindValue(':full_name', $data['fullName'] ?? null);
        $stmt->bindValue(':role', $data['role'] ?? 'buyer');
        $stmt->execute();
        
        // Récupérer l'ID de l'utilisateur inséré
        $userId = $pdo->lastInsertId();
        
        // Récupérer l'utilisateur nouvellement créé
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->bindValue(':id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Créer une session utilisateur
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['username'] = $user['username'];
        
        // Supprimer le mot de passe de la réponse
        unset($user['password']);
        
        jsonResponse([
            'success' => true,
            'message' => 'Inscription réussie',
            'user' => $user
        ], 201);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Erreur lors de l\'inscription: ' . $e->getMessage()], 500);
    }
}

/**
 * Déconnexion de l'utilisateur
 */
function logout() {
    // Détruire la session
    session_unset();
    session_destroy();
    
    jsonResponse([
        'success' => true,
        'message' => 'Déconnexion réussie'
    ]);
}

/**
 * Récupérer l'utilisateur actuellement connecté
 */
function getCurrentUser() {
    if (!isLoggedIn()) {
        jsonResponse(['error' => 'Non authentifié'], 401);
    }
    
    try {
        $pdo = connectDB();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->bindValue(':id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->execute();
        
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            // Session existe mais utilisateur non trouvé dans la base de données
            session_unset();
            session_destroy();
            jsonResponse(['error' => 'Utilisateur non trouvé'], 401);
        }
        
        // Supprimer le mot de passe de la réponse
        unset($user['password']);
        
        jsonResponse($user);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Erreur lors de la récupération des informations de l\'utilisateur: ' . $e->getMessage()], 500);
    }
}