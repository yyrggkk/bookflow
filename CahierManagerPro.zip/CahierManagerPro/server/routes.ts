import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertBookSchema, insertCartItemSchema, insertOrderSchema, insertOrderItemSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Category routes
  app.get("/api/categories", async (req, res) => {
    const categories = await storage.getAllCategories();
    res.json(categories);
  });

  // Book routes
  app.get("/api/books", async (req, res) => {
    const { featured, bestSeller, categoryId, search, limit } = req.query;
    
    let books;
    if (featured === 'true') {
      books = await storage.getFeaturedBooks(Number(limit) || 5);
    } else if (bestSeller === 'true') {
      books = await storage.getBestSellerBooks(Number(limit) || 4);
    } else if (categoryId) {
      books = await storage.getBooksByCategory(Number(categoryId));
    } else if (search) {
      books = await storage.searchBooks(search.toString());
    } else {
      books = await storage.getAllBooks();
    }
    
    res.json(books);
  });

  app.get("/api/books/:id", async (req, res) => {
    const id = Number(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID de livre invalide" });
    }
    
    const book = await storage.getBook(id);
    if (!book) {
      return res.status(404).json({ message: "Livre non trouvé" });
    }
    
    res.json(book);
  });

  app.post("/api/books", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'seller') {
      return res.status(403).json({ message: "Accès refusé" });
    }

    try {
      const bookData = insertBookSchema.parse(req.body);
      bookData.sellerId = req.user.id;
      
      const newBook = await storage.createBook(bookData);
      res.status(201).json(newBook);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données de livre invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la création du livre" });
    }
  });

  app.put("/api/books/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'seller') {
      return res.status(403).json({ message: "Accès refusé" });
    }

    const id = Number(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID de livre invalide" });
    }

    const book = await storage.getBook(id);
    if (!book) {
      return res.status(404).json({ message: "Livre non trouvé" });
    }

    if (book.sellerId !== req.user.id) {
      return res.status(403).json({ message: "Vous ne pouvez pas modifier ce livre" });
    }

    try {
      const bookData = insertBookSchema.parse(req.body);
      bookData.sellerId = req.user.id;
      
      const updatedBook = await storage.updateBook(id, bookData);
      res.json(updatedBook);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données de livre invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la mise à jour du livre" });
    }
  });

  app.delete("/api/books/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'seller') {
      return res.status(403).json({ message: "Accès refusé" });
    }

    const id = Number(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID de livre invalide" });
    }

    const book = await storage.getBook(id);
    if (!book) {
      return res.status(404).json({ message: "Livre non trouvé" });
    }

    if (book.sellerId !== req.user.id) {
      return res.status(403).json({ message: "Vous ne pouvez pas supprimer ce livre" });
    }

    await storage.deleteBook(id);
    res.sendStatus(204);
  });

  // Cart routes
  app.get("/api/cart", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    const cartItems = await storage.getCartItems(req.user.id);
    res.json(cartItems);
  });

  app.post("/api/cart", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      const cartItemData = insertCartItemSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      const newCartItem = await storage.addToCart(cartItemData);
      res.status(201).json(newCartItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de l'ajout au panier" });
    }
  });

  app.put("/api/cart/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    const id = Number(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID de l'élément du panier invalide" });
    }

    const cartItem = await storage.getCartItem(id);
    if (!cartItem || cartItem.userId !== req.user.id) {
      return res.status(404).json({ message: "Élément du panier non trouvé" });
    }

    try {
      const { quantity } = req.body;
      if (typeof quantity !== 'number' || quantity < 1) {
        return res.status(400).json({ message: "Quantité invalide" });
      }
      
      const updatedCartItem = await storage.updateCartItemQuantity(id, quantity);
      res.json(updatedCartItem);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la mise à jour de la quantité" });
    }
  });

  app.delete("/api/cart/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    const id = Number(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID de l'élément du panier invalide" });
    }

    const cartItem = await storage.getCartItem(id);
    if (!cartItem || cartItem.userId !== req.user.id) {
      return res.status(404).json({ message: "Élément du panier non trouvé" });
    }

    await storage.removeFromCart(id);
    res.sendStatus(204);
  });

  app.delete("/api/cart", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    await storage.clearCart(req.user.id);
    res.sendStatus(204);
  });

  // Order routes
  app.get("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    // Get orders based on user role
    let orders;
    if (req.user.role === 'seller') {
      orders = await storage.getSellerOrders(req.user.id);
    } else {
      orders = await storage.getUserOrders(req.user.id);
    }

    res.json(orders);
  });

  app.get("/api/orders/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    const id = Number(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID de commande invalide" });
    }

    const order = await storage.getOrder(id);
    if (!order) {
      return res.status(404).json({ message: "Commande non trouvée" });
    }

    // Check if user has permission to view this order
    if (req.user.role === 'buyer' && order.userId !== req.user.id) {
      return res.status(403).json({ message: "Accès refusé" });
    }

    if (req.user.role === 'seller') {
      const orderItems = await storage.getOrderItems(id);
      const hasSellerItems = orderItems.some(async (item) => {
        const book = await storage.getBook(item.bookId);
        return book && book.sellerId === req.user.id;
      });

      if (!hasSellerItems) {
        return res.status(403).json({ message: "Accès refusé" });
      }
    }

    const orderWithItems = await storage.getOrderWithItems(id);
    res.json(orderWithItems);
  });

  app.post("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      // Get cart items
      const cartItems = await storage.getCartItems(req.user.id);
      if (cartItems.length === 0) {
        return res.status(400).json({ message: "Le panier est vide" });
      }

      // Calculate total amount
      let totalAmount = 0;
      for (const item of cartItems) {
        const book = await storage.getBook(item.bookId);
        if (!book) {
          return res.status(400).json({ message: `Livre non trouvé: ${item.bookId}` });
        }
        if (book.stock < item.quantity) {
          return res.status(400).json({ message: `Stock insuffisant pour: ${book.title}` });
        }
        totalAmount += book.price * item.quantity;
      }

      // Create order
      const orderData = insertOrderSchema.parse({
        ...req.body,
        userId: req.user.id,
        totalAmount
      });
      
      const newOrder = await storage.createOrder(orderData);

      // Create order items
      for (const item of cartItems) {
        const book = await storage.getBook(item.bookId);
        if (!book) continue;

        const orderItemData = insertOrderItemSchema.parse({
          orderId: newOrder.id,
          bookId: item.bookId,
          quantity: item.quantity,
          price: book.price
        });
        
        await storage.createOrderItem(orderItemData);
        
        // Update book stock
        await storage.updateBookStock(item.bookId, book.stock - item.quantity);
      }

      // Clear cart
      await storage.clearCart(req.user.id);

      const orderWithItems = await storage.getOrderWithItems(newOrder.id);
      res.status(201).json(orderWithItems);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la création de la commande" });
    }
  });

  app.put("/api/orders/:id/status", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'seller') {
      return res.status(403).json({ message: "Accès refusé" });
    }

    const id = Number(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID de commande invalide" });
    }

    const { status } = req.body;
    if (!status || !['processing', 'shipped', 'delivered', 'cancelled'].includes(status)) {
      return res.status(400).json({ message: "Statut invalide" });
    }

    const order = await storage.getOrder(id);
    if (!order) {
      return res.status(404).json({ message: "Commande non trouvée" });
    }

    // Check if seller owns any books in this order
    const orderItems = await storage.getOrderItems(id);
    let hasSellerItems = false;
    
    for (const item of orderItems) {
      const book = await storage.getBook(item.bookId);
      if (book && book.sellerId === req.user.id) {
        hasSellerItems = true;
        break;
      }
    }

    if (!hasSellerItems) {
      return res.status(403).json({ message: "Accès refusé" });
    }

    const updatedOrder = await storage.updateOrderStatus(id, status);
    res.json(updatedOrder);
  });

  const httpServer = createServer(app);
  return httpServer;
}
