import { 
  User, InsertUser, Book, InsertBook, Category, InsertCategory, 
  CartItem, InsertCartItem, Order, InsertOrder, OrderItem, InsertOrderItem 
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category operations
  getAllCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Book operations
  getAllBooks(): Promise<Book[]>;
  getBook(id: number): Promise<Book | undefined>;
  getFeaturedBooks(limit?: number): Promise<Book[]>;
  getBestSellerBooks(limit?: number): Promise<Book[]>;
  getBooksByCategory(categoryId: number): Promise<Book[]>;
  getBooksBySeller(sellerId: number): Promise<Book[]>;
  searchBooks(query: string): Promise<Book[]>;
  createBook(book: InsertBook): Promise<Book>;
  updateBook(id: number, book: InsertBook): Promise<Book>;
  updateBookStock(id: number, stock: number): Promise<Book>;
  deleteBook(id: number): Promise<void>;
  
  // Cart operations
  getCartItems(userId: number): Promise<(CartItem & { book: Book })[]>;
  getCartItem(id: number): Promise<CartItem | undefined>;
  addToCart(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItemQuantity(id: number, quantity: number): Promise<CartItem>;
  removeFromCart(id: number): Promise<void>;
  clearCart(userId: number): Promise<void>;
  
  // Order operations
  getOrder(id: number): Promise<Order | undefined>;
  getUserOrders(userId: number): Promise<Order[]>;
  getSellerOrders(sellerId: number): Promise<Order[]>;
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  getOrderWithItems(orderId: number): Promise<Order & { items: (OrderItem & { book: Book })[] }>;
  createOrder(order: InsertOrder): Promise<Order>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  updateOrderStatus(id: number, status: string): Promise<Order>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private books: Map<number, Book>;
  private cartItems: Map<number, CartItem>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  
  private userIdCounter: number;
  private categoryIdCounter: number;
  private bookIdCounter: number;
  private cartItemIdCounter: number;
  private orderIdCounter: number;
  private orderItemIdCounter: number;
  
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.books = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    
    this.userIdCounter = 1;
    this.categoryIdCounter = 1;
    this.bookIdCounter = 1;
    this.cartItemIdCounter = 1;
    this.orderIdCounter = 1;
    this.orderItemIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // Clear expired sessions every day
    });
    
    // Initialize with sample data
    this.initializeCategories();
  }

  private async initializeCategories() {
    const categoriesData: InsertCategory[] = [
      { name: "Romans", icon: "auto_stories" },
      { name: "Sciences Humaines", icon: "psychology" },
      { name: "Science-Fiction", icon: "science" },
      { name: "Jeunesse", icon: "child_care" },
      { name: "Histoire", icon: "history_edu" },
    ];
    
    for (const category of categoriesData) {
      await this.createCategory(category);
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...userData, id };
    this.users.set(id, user);
    return user;
  }

  // Category operations
  async getAllCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(categoryData: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = { ...categoryData, id };
    this.categories.set(id, category);
    return category;
  }

  // Book operations
  async getAllBooks(): Promise<Book[]> {
    return Array.from(this.books.values());
  }

  async getBook(id: number): Promise<Book | undefined> {
    return this.books.get(id);
  }

  async getFeaturedBooks(limit: number = 5): Promise<Book[]> {
    return Array.from(this.books.values())
      .filter(book => book.featured)
      .slice(0, limit);
  }

  async getBestSellerBooks(limit: number = 4): Promise<Book[]> {
    return Array.from(this.books.values())
      .filter(book => book.bestSeller)
      .slice(0, limit);
  }

  async getBooksByCategory(categoryId: number): Promise<Book[]> {
    return Array.from(this.books.values())
      .filter(book => book.categoryId === categoryId);
  }

  async getBooksBySeller(sellerId: number): Promise<Book[]> {
    return Array.from(this.books.values())
      .filter(book => book.sellerId === sellerId);
  }

  async searchBooks(query: string): Promise<Book[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.books.values())
      .filter(book => 
        book.title.toLowerCase().includes(lowercaseQuery) || 
        book.author.toLowerCase().includes(lowercaseQuery) ||
        book.description.toLowerCase().includes(lowercaseQuery)
      );
  }

  async createBook(bookData: InsertBook): Promise<Book> {
    const id = this.bookIdCounter++;
    const now = new Date();
    const book: Book = { 
      ...bookData, 
      id, 
      rating: bookData.rating || 0,
      numReviews: bookData.numReviews || 0,
      featured: bookData.featured || false,
      bestSeller: bookData.bestSeller || false,
      createdAt: now
    };
    this.books.set(id, book);
    return book;
  }

  async updateBook(id: number, bookData: InsertBook): Promise<Book> {
    const existingBook = this.books.get(id);
    if (!existingBook) {
      throw new Error("Book not found");
    }
    
    const updatedBook: Book = { 
      ...existingBook, 
      ...bookData, 
      id
    };
    this.books.set(id, updatedBook);
    return updatedBook;
  }

  async updateBookStock(id: number, stock: number): Promise<Book> {
    const book = this.books.get(id);
    if (!book) {
      throw new Error("Book not found");
    }
    
    const updatedBook: Book = { ...book, stock };
    this.books.set(id, updatedBook);
    return updatedBook;
  }

  async deleteBook(id: number): Promise<void> {
    this.books.delete(id);
  }

  // Cart operations
  async getCartItems(userId: number): Promise<(CartItem & { book: Book })[]> {
    const items = Array.from(this.cartItems.values())
      .filter(item => item.userId === userId);
    
    return Promise.all(items.map(async item => {
      const book = await this.getBook(item.bookId);
      return {
        ...item,
        book: book as Book
      };
    }));
  }

  async getCartItem(id: number): Promise<CartItem | undefined> {
    return this.cartItems.get(id);
  }

  async addToCart(cartItemData: InsertCartItem): Promise<CartItem> {
    // Check if book exists
    const book = await this.getBook(cartItemData.bookId);
    if (!book) {
      throw new Error("Book not found");
    }
    
    // Check if item is already in cart
    const existingItem = Array.from(this.cartItems.values()).find(
      item => item.userId === cartItemData.userId && item.bookId === cartItemData.bookId
    );
    
    if (existingItem) {
      // Update quantity instead of creating new item
      const newQuantity = existingItem.quantity + cartItemData.quantity;
      return this.updateCartItemQuantity(existingItem.id, newQuantity);
    }
    
    // Add new item
    const id = this.cartItemIdCounter++;
    const cartItem: CartItem = { ...cartItemData, id };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async updateCartItemQuantity(id: number, quantity: number): Promise<CartItem> {
    const item = this.cartItems.get(id);
    if (!item) {
      throw new Error("Cart item not found");
    }
    
    const updatedItem: CartItem = { ...item, quantity };
    this.cartItems.set(id, updatedItem);
    return updatedItem;
  }

  async removeFromCart(id: number): Promise<void> {
    this.cartItems.delete(id);
  }

  async clearCart(userId: number): Promise<void> {
    const itemsToRemove = Array.from(this.cartItems.values())
      .filter(item => item.userId === userId)
      .map(item => item.id);
    
    for (const id of itemsToRemove) {
      this.cartItems.delete(id);
    }
  }

  // Order operations
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getUserOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getSellerOrders(sellerId: number): Promise<Order[]> {
    // Get all orders
    const allOrders = Array.from(this.orders.values());
    const sellerOrders: Order[] = [];
    
    // For each order, check if it contains items from this seller
    for (const order of allOrders) {
      const orderItems = await this.getOrderItems(order.id);
      
      for (const item of orderItems) {
        const book = await this.getBook(item.bookId);
        if (book && book.sellerId === sellerId) {
          sellerOrders.push(order);
          break;
        }
      }
    }
    
    return sellerOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values())
      .filter(item => item.orderId === orderId);
  }

  async getOrderWithItems(orderId: number): Promise<Order & { items: (OrderItem & { book: Book })[] }> {
    const order = await this.getOrder(orderId);
    if (!order) {
      throw new Error("Order not found");
    }
    
    const items = await this.getOrderItems(orderId);
    const itemsWithBooks = await Promise.all(items.map(async item => {
      const book = await this.getBook(item.bookId);
      return {
        ...item,
        book: book as Book
      };
    }));
    
    return {
      ...order,
      items: itemsWithBooks
    };
  }

  async createOrder(orderData: InsertOrder): Promise<Order> {
    const id = this.orderIdCounter++;
    const now = new Date();
    const order: Order = { 
      ...orderData, 
      id, 
      createdAt: now
    };
    this.orders.set(id, order);
    return order;
  }

  async createOrderItem(orderItemData: InsertOrderItem): Promise<OrderItem> {
    const id = this.orderItemIdCounter++;
    const orderItem: OrderItem = { ...orderItemData, id };
    this.orderItems.set(id, orderItem);
    return orderItem;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order> {
    const order = this.orders.get(id);
    if (!order) {
      throw new Error("Order not found");
    }
    
    const updatedOrder: Order = { ...order, status: status as any };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }
}

export const storage = new MemStorage();
